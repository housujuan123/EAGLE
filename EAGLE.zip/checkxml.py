import os
import xml.etree.ElementTree as ET

def check_xml_files(directory):
    for filename in os.listdir(directory):
        if filename.endswith(".xml"):
            xml_path = os.path.join(directory, filename)
            tree = ET.parse(xml_path)
            root = tree.getroot()
            for obj in root.findall("object"):
                bbox = obj.find("bndbox")
                xmin = int(bbox.find("xmin").text)
                ymin = int(bbox.find("ymin").text)
                xmax = int(bbox.find("xmax").text)
                ymax = int(bbox.find("ymax").text)

                if xmin > xmax or ymin > ymax:
                    print(f"Invalid bounding box found in file: {filename}")
                    break  # 如果找到一个无效的边界框就停止对该文件的处理

# 调用函数并传入包含 XML 文件的目录路径
directory_path = "E:/数据集/openlogo/VOC2007/Annotations"
check_xml_files(directory_path)