#!/bin/bash

bash configs/EVAL_M_OWOD_BENCHMARK.sh
