# ------------------------------------------------------------------------
# PROB: Probabilistic Objectness for Open World Object Detection 
# Orr Zohar, Jackson Wang, Serena Yeung
# -----------------------------------------------------------------------
# Modified from OW-DETR: Open-world Detection Transformer
# Akshita Gupta^, Sanath Narayan^, K J Joseph, Salman Khan, Fahad Shahbaz Khan, Mubarak Shah
# https://arxiv.org/pdf/2112.01513.pdf
# ------------------------------------------------------------------------
# Modified from Deformable DETR (https://github.com/fundamentalvision/Deformable-DETR)
# Copyright (c) 2020 SenseTime. All Rights Reserved.
# ------------------------------------------------------------------------

import argparse
import datetime
import json
import random
import time
from pathlib import Path
import os
import numpy as np
import torch
from torch.utils.data import DataLoader
import datasets
import util.misc as utils
import datasets.samplers as samplers
from datasets import build_dataset, get_coco_api_from_dataset
from datasets.coco import make_coco_transforms
from datasets.torchvision_datasets.open_world import OWDetection
from engine import evaluate, train_one_epoch, get_exemplar_replay
from models import build_model
import wandb

torch.cuda.set_device(3)


def get_args_parser():
    parser = argparse.ArgumentParser('Deformable DETR Detector', add_help=False)

    ################ Deformable DETR ################
    # 优化器参数
    parser.add_argument('--lr', default=8e-5, type=float)  # 学习率
    parser.add_argument('--lr_backbone_names', default=["backbone.0"], type=str, nargs='+')  # 骨干网络学习率名称
    parser.add_argument('--lr_backbone', default=8e-6, type=float)  # 骨干网络学习率
    parser.add_argument('--lr_linear_proj_names', default=['reference_points', 'sampling_offsets'], type=str,
                        nargs='+')  # 线性投影层学习率名称
    parser.add_argument('--lr_linear_proj_mult', default=0.1, type=float)  # 线性投影层学习率倍数
    parser.add_argument('--batch_size', default=2, type=int)  # 批量大小
    parser.add_argument('--weight_decay', default=1e-4, type=float)  # 权重衰减因子
    parser.add_argument('--epochs', default=41, type=int)  # 训练轮数
    parser.add_argument('--lr_drop', default=40, type=int)  # 学习率下降轮数
    parser.add_argument('--lr_drop_epochs', default=None, type=int, nargs='+')  # 学习率下降计划
    parser.add_argument('--clip_max_norm', default=0.1, type=float, help='gradient clipping max norm')  # 梯度剪裁的最大范数
    parser.add_argument('--sgd', action='store_true')  # 是否使用随机梯度下降法
    # Deformable DETR模型变种参数
    parser.add_argument('--with_box_refine', default=False, action='store_true')  # 是否使用边框微调模块
    parser.add_argument('--two_stage', default=False, action='store_true')  # 是否使用两阶段检测模式
    parser.add_argument('--masks', default=False, action='store_true',
                        help="Train segmentation head if the flag is provided")  # 是否训练分割头部
    parser.add_argument('--backbone', default='dino_resnet50', type=str,
                        help="Name of the convolutional backbone to use")  # 使用的骨干网络名称

    # 模型参数
    parser.add_argument('--frozen_weights', type=str, default=None,
                        help="Path to the pretrained model. If set, only the mask head will be trained")  # 预训练模型路径
    parser.add_argument('--dilation', action='store_true',
                        help="If true, we replace stride with dilation in the last convolutional block (DC5)")  # 是否使用膨胀卷积操作
    parser.add_argument('--position_embedding', default='sine', type=str, choices=('sine', 'learned'),
                        help="Type of positional embedding to use on top of the image features")  # 位置编码类型
    parser.add_argument('--position_embedding_scale', default=2 * np.pi, type=float, help="position / size * scale")
    parser.add_argument('--num_feature_levels', default=4, type=int, help='number of feature levels')  # 特征层数

    # * Transformer
    parser.add_argument('--enc_layers', default=6, type=int,
                        help="Number of encoding layers in the transformer")  # 编码器层数
    parser.add_argument('--dec_layers', default=6, type=int,
                        help="Number of decoding layers in the transformer")  # 解码器层数
    parser.add_argument('--local_dec_layers', default=6, type=int, help="Number of decoding layers in the transformer")
    parser.add_argument('--class_dec_layers', default=6, type=int, help="Number of decoding layers in the transformer")
    parser.add_argument('--dim_feedforward', default=1024, type=int,
                        help="Intermediate size of the feedforward layers in the transformer blocks")  # 前馈层维度
    parser.add_argument('--hidden_dim', default=256, type=int,
                        help="Size of the embeddings (dimension of the transformer)")  # 隐藏层维度
    parser.add_argument('--dropout', default=0.1, type=float, help="Dropout applied in the transformer")  # dropout概率
    parser.add_argument('--nheads', default=8, type=int,
                        help="Number of attention heads inside the transformer's attentions")  # 注意力头数
    parser.add_argument('--num_queries', default=100, type=int, help="Number of query slots")  # 查询槽数量
    parser.add_argument('--dec_n_points', default=4, type=int)
    parser.add_argument('--enc_n_points', default=4, type=int)

    # 损失函数参数
    parser.add_argument('--no_aux_loss', dest='aux_loss', action='store_false',
                        help="Disables auxiliary decoding losses (loss at each layer)")  # 是否关闭辅助损失函数
    # * Matcher
    parser.add_argument('--set_cost_class', default=2, type=float,
                        help="Class coefficient in the matching cost")  # 等价类类别损失系数
    parser.add_argument('--set_cost_bbox', default=5, type=float,
                        help="L1 box coefficient in the matching cost")  # 等价类框回归损失系数
    parser.add_argument('--set_cost_giou', default=2, type=float,
                        help="giou box coefficient in the matching cost")  # 等价类GIoU损失系数
    # Loss coefficients
    parser.add_argument('--cls_loss_coef', default=2, type=float)  # 类别损失系数
    parser.add_argument('--bbox_loss_coef', default=5, type=float)  # 框回归损失系数
    parser.add_argument('--giou_loss_coef', default=2, type=float)  # GIoU损失系数
    parser.add_argument('--focal_alpha', default=0.25, type=float)  # Focal loss的衡量指标

    # 数据集参数
    parser.add_argument('--coco_panoptic_path', type=str)  # COCO数据集路径
    parser.add_argument('--remove_difficult', action='store_true')  # 是否移除难例
    parser.add_argument('--output_dir', default='', help='path where to save, empty for no saving')  # 输出路径
    parser.add_argument('--device', default='cuda:3', help='device to use for training / testing')  # 训练、测试设备
    parser.add_argument('--seed', default=42, type=int)  # 随机种子
    parser.add_argument('--resume', default='/icislab/volume1/yuanzhongming/prob1/exps/MOWODB/PROB/t4_ft/checkpoint.pth', help='resume from checkpoint')  # 继续之前的训练状态
    parser.add_argument('--start_epoch', default=0, type=int, metavar='N', help='start epoch')  # 开始训练的轮数
    parser.add_argument('--eval', action='store_true')  # 是否进行测试
    parser.add_argument('--viz', action='store_true')  # 是否可视化
    parser.add_argument('--eval_every', default=5, type=int)  # 每隔多少轮进行一次测试
    parser.add_argument('--num_workers', default=3, type=int)  # 数据加载时的进程数
    parser.add_argument('--cache_mode', default=False, action='store_true',
                        help='whether to cache images on memory')  # 是否缓存图片到内存

    ################ OW-DETR ################
    # OW-DETR模型参数
    parser.add_argument('--PREV_INTRODUCED_CLS', default=0, type=int)
    parser.add_argument('--CUR_INTRODUCED_CLS', default=19, type=int)
    parser.add_argument('--unmatched_boxes', default=True, action='store_true')
    parser.add_argument('--top_unk', default=5, type=int)
    parser.add_argument('--featdim', default=1024, type=int)
    parser.add_argument('--invalid_cls_logits', default=False, action='store_true', help='owod setting')
    parser.add_argument('--NC_branch', default=False, action='store_true')
    parser.add_argument('--bbox_thresh', default=0.3, type=float)
    parser.add_argument('--pretrain', default='', help='initialized from the pre-training model')
    parser.add_argument('--nc_loss_coef', default=2, type=float)
    parser.add_argument('--train_set', default='', help='training txt files')
    parser.add_argument('--test_set', default='', help='testing txt files')
    parser.add_argument('--num_classes', default=81, type=int)
    parser.add_argument('--nc_epoch', default=9, type=int)
    parser.add_argument('--dataset', default='TOWOD',
                        help='defines which dataset is used. Built for: {TOWOD, OWDETR, VOC2007}')
    parser.add_argument('--data_root', default='/icislab/volume1/yuanzhongming/OW-DETR-main/data/VOC2007/OWOD/',
                        type=str)
    parser.add_argument('--unk_conf_w', default=1.0, type=float)

    ################ PROB OWOD ################
    # model config
    parser.add_argument('--model_type', default='prob', type=str)

    # logging
    parser.add_argument('--wandb_name', default='${WANDB_NAME}_t1', type=str)
    parser.add_argument('--wandb_project', default='PROB_OWOD', type=str)

    # model hyperparameters
    parser.add_argument('--obj_loss_coef', default=1e-3, type=float)
    parser.add_argument('--obj_temp', default=1.3, type=float)  # 默认1
    parser.add_argument('--freeze_prob_model', default=False, action='store_true',
                        help='freeze model probabistic estimation')

    # Exemplar replay selection
    parser.add_argument('--num_inst_per_class', default=50, type=int, help="number of instances per class")
    parser.add_argument('--exemplar_replay_selection', default=True, action='store_true',
                        help='use learned exemplar selection')
    parser.add_argument('--exemplar_replay_max_length', default=850, type=int,
                        help="max number of images that can be saves")
    parser.add_argument('--exemplar_replay_dir', default='', type=str, help="directory of exemplar replay txt files")
    parser.add_argument('--exemplar_replay_prev_file', default='', type=str, help="path to previous ft file")
    parser.add_argument('--exemplar_replay_cur_file', default='', type=str, help="path to current ft file")
    parser.add_argument('--exemplar_replay_random', default=False, action='store_true', help='make selection random')
    return parser


def main(args):
    wandb = None
    # 初始化 wandb（可视化工具） 以及 distributed（分布式）训练模式等参数
    """if len(args.wandb_project) > 0:
        if len(args.wandb_name) > 0:
            wandb.init(project=args.wandb_project, entity="prob-", group=args.wandb_name)
        else:
            wandb.init(project=args.wandb_project, entity="prob-")
        wandb.config = args"""

    utils.init_distributed_mode(args)  # 初始化分布式训练模式
    print("git:\n  {}\n".format(utils.get_sha()))  # 输出 git 版本号

    if args.frozen_weights is not None:
        assert args.masks, "Frozen training is meant for segmentation only"  # 如果设置了冻结权重，则仅训练与分割相关的参数。
    print(args)

    device = torch.device(args.device)  # 设置设备

    # 设置随机种子
    seed = args.seed + utils.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

    # 构建模型
    model, criterion, postprocessors, exemplar_selection = build_model(args, mode=args.model_type)
    model.to(device)

    model_without_ddp = model
    print(model_without_ddp)
    n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print('number of params:', n_parameters)  # 输出模型的参数数量

    # 获取数据集
    dataset_train, dataset_val = get_datasets(args)

    # 设置采样器
    if args.distributed:
        if args.cache_mode:
            sampler_train = samplers.NodeDistributedSampler(dataset_train)
            sampler_val = samplers.NodeDistributedSampler(dataset_val, shuffle=False)
        else:
            sampler_train = samplers.DistributedSampler(dataset_train)
            sampler_val = samplers.DistributedSampler(dataset_val, shuffle=False)
    else:
        sampler_train = torch.utils.data.RandomSampler(dataset_train)
        sampler_val = torch.utils.data.SequentialSampler(dataset_val)

    # 设置批次采样器和数据加载器
    batch_sampler_train = torch.utils.data.BatchSampler(sampler_train, args.batch_size, drop_last=True)
    data_loader_train = DataLoader(dataset_train, batch_sampler=batch_sampler_train,
                                   collate_fn=utils.collate_fn, num_workers=args.num_workers,
                                   pin_memory=True)
    data_loader_val = DataLoader(dataset_val, args.batch_size, sampler=sampler_val,
                                 drop_last=False, collate_fn=utils.collate_fn, num_workers=args.num_workers,
                                 pin_memory=True)

    # 设置学习率和优化器
    def match_name_keywords(n, name_keywords):
        out = False
        for b in name_keywords:
            if b in n:
                out = True
                break
        return out

    param_dicts = [
        {
            "params":
                [p for n, p in model_without_ddp.named_parameters()
                 if not match_name_keywords(n, args.lr_backbone_names) and not match_name_keywords(n,
                                                                                                   args.lr_linear_proj_names) and p.requires_grad],
            "lr": args.lr,
        },
        {
            "params": [p for n, p in model_without_ddp.named_parameters() if
                       match_name_keywords(n, args.lr_backbone_names) and p.requires_grad],
            "lr": args.lr_backbone,
        },
        {
            "params": [p for n, p in model_without_ddp.named_parameters() if
                       match_name_keywords(n, args.lr_linear_proj_names) and p.requires_grad],
            "lr": args.lr * args.lr_linear_proj_mult,
        }
    ]
    if args.sgd:
        optimizer = torch.optim.SGD(param_dicts, lr=args.lr, momentum=0.9,
                                    weight_decay=args.weight_decay)
    else:
        optimizer = torch.optim.AdamW(param_dicts, lr=args.lr,
                                      weight_decay=args.weight_decay)
    lr_scheduler = torch.optim.lr_scheduler.StepLR(optimizer, args.lr_drop)

    # 如果是分布式训练，则使用分布式模型
    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.gpu])
        model_without_ddp = model.module

    # 获取评估数据集
    if args.dataset == "coco_panoptic":
        coco_val = datasets.coco.build("val", args)
        base_ds = get_coco_api_from_dataset(coco_val)
    elif args.dataset == "coco":
        base_ds = get_coco_api_from_dataset(dataset_val)
    else:
        base_ds = dataset_val

    # 如果设置了预训练模型，则从预训练模型中加载参数初始化模型
    if args.frozen_weights is not None:
        checkpoint = torch.load(args.frozen_weights, map_location='cpu')
        model_without_ddp.detr.load_state_dict(checkpoint['model'])

    output_dir = Path(args.output_dir)

    # 如果设置了预训练模型，则从预训练模型的 epoch 继续训练
    if args.pretrain:
        print('Initialized from the pre-training model')
        checkpoint = torch.load(args.pretrain, map_location='cpu')
        state_dict = checkpoint['model']
        msg = model_without_ddp.load_state_dict(state_dict, strict=False)
        print(msg)
        args.start_epoch = checkpoint['epoch'] + 1
        if args.eval:
            test_stats, coco_evaluator = evaluate(model, criterion, postprocessors, data_loader_val, base_ds, device,
                                                  args.output_dir, args)
            return

    if args.resume:
        if args.resume.startswith('https'):
            checkpoint = torch.hub.load_state_dict_from_url(
                args.resume, map_location='cpu', check_hash=True)
        else:
            checkpoint = torch.load(args.resume, map_location='cpu')
        missing_keys, unexpected_keys = model_without_ddp.load_state_dict(checkpoint['model'], strict=False)
        unexpected_keys = [k for k in unexpected_keys if not (k.endswith('total_params') or k.endswith('total_ops'))]
        if len(missing_keys) > 0:
            print('Missing Keys: {}'.format(missing_keys))
        if len(unexpected_keys) > 0:
            print('Unexpected Keys: {}'.format(unexpected_keys))
        if not args.eval and 'optimizer' in checkpoint and 'lr_scheduler' in checkpoint and 'epoch' in checkpoint:
            import copy
            p_groups = copy.deepcopy(optimizer.param_groups)
            optimizer.load_state_dict(checkpoint['optimizer'])
            for pg, pg_old in zip(optimizer.param_groups, p_groups):
                pg['lr'] = pg_old['lr']
                pg['initial_lr'] = pg_old['initial_lr']
            print(optimizer.param_groups)
            lr_scheduler.load_state_dict(checkpoint['lr_scheduler'])
            # todo: this is a hack for doing experiment that resume from checkpoint and also modify lr scheduler (e.g., decrease lr in advance).
            args.override_resumed_lr_drop = True
            if args.override_resumed_lr_drop:
                print(
                    'Warning: (hack) args.override_resumed_lr_drop is set to True, so args.lr_drop would override lr_drop in resumed lr_scheduler.')
                lr_scheduler.step_size = args.lr_drop
                lr_scheduler.base_lrs = list(map(lambda group: group['initial_lr'], optimizer.param_groups))
            lr_scheduler.step(lr_scheduler.last_epoch)
            args.start_epoch = checkpoint['epoch'] + 1
        # check the resumed model
        if (not args.eval and not args.viz and args.dataset in ['coco', 'voc']):
            test_stats, coco_evaluator = evaluate(
                model, criterion, postprocessors, data_loader_val, base_ds, device, args.output_dir, args
            )
        if args.eval:
            test_stats, coco_evaluator = evaluate(model, criterion, postprocessors, data_loader_val, base_ds, device,
                                                  args.output_dir, args)
            if args.output_dir:
                utils.save_on_master(coco_evaluator.coco_eval["bbox"].eval, output_dir / "eval.pth")
            return

    if args.freeze_prob_model:
        if isinstance(model_without_ddp.prob_obj_head, torch.nn.ModuleList):
            for obj_head in model_without_ddp.prob_obj_head:
                obj_head.freeze_prob_model()
        else:
            model_without_ddp.prob_obj_head.freeze_prob_model()

        obj_bn_mean_before = model_without_ddp.prob_obj_head[0].objectness_bn.running_mean

    print(f'Start training from epoch {args.start_epoch} to {args.epochs}')
    start_time = time.time()
    for epoch in range(args.start_epoch, args.epochs):
        if args.distributed:
            sampler_train.set_epoch(epoch)

        train_stats = train_one_epoch(
            model, criterion, data_loader_train, optimizer, device, epoch, args.nc_epoch, args.clip_max_norm, wandb)

        lr_scheduler.step()
        if args.output_dir:
            checkpoint_paths = [output_dir / 'checkpoint.pth']
            # extra checkpoint before LR drop and every 5 epochs
            if (epoch + 1) % args.lr_drop == 0 or (
                    epoch % args.eval_every == 0 or (args.epochs - epoch) < 1):
                test_stats, coco_evaluator = evaluate(
                    model, criterion, postprocessors, data_loader_val, base_ds, device, args.output_dir, args)
                checkpoint_paths.append(output_dir / f'checkpoint{epoch:04}.pth')
                if wandb is not None:
                    test_stats["metrics"]['epoch'] = epoch
                    wandb.log({str(key): val for key, val in test_stats["metrics"].items()})
            #elif epoch > args.epochs - 6:
            #    checkpoint_paths.append(output_dir / f'checkpoint{epoch:04}.pth')

            else:
                test_stats = {}

            for checkpoint_path in checkpoint_paths:
                utils.save_on_master({
                    'model': model_without_ddp.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'lr_scheduler': lr_scheduler.state_dict(),
                    'epoch': epoch,
                    'args': args,
                }, checkpoint_path)

        log_stats = {**{f'train_{k}': v for k, v in train_stats.items()},
                     **{f'test_{k}': v for k, v in test_stats.items()},
                     'epoch': epoch,
                     'n_parameters': n_parameters}

        if args.output_dir and utils.is_main_process():
            with (output_dir / "log.txt").open("a") as f:
                f.write(json.dumps(log_stats) + "\n")
            if args.dataset in ['owod', 'owdetr','logo'] and epoch % args.eval_every == 0 and epoch > 0:
                # for evaluation logs
                if coco_evaluator is not None:
                    (output_dir / 'eval').mkdir(exist_ok=True)
                    if "bbox" in coco_evaluator.coco_eval:
                        filenames = ['latest.pth']
                        if epoch % 50 == 0:
                            filenames.append(f'{epoch:03}.pth')
                        for name in filenames:
                            torch.save(coco_evaluator.coco_eval["bbox"].eval,
                                       output_dir / "eval" / name)
    if args.exemplar_replay_selection:
        image_sorted_scores = get_exemplar_replay(model, exemplar_selection, device, data_loader_train)
        create_ft_dataset(args, image_sorted_scores)
    total_time = time.time() - start_time
    total_time_str = str(datetime.timedelta(seconds=int(total_time)))
    print('Training time {}'.format(total_time_str))
    return


def get_datasets(args):
    print(args.dataset)

    train_set = args.train_set
    test_set = args.test_set
    dataset_train = OWDetection(args, args.data_root, image_set=args.train_set,
                                transforms=make_coco_transforms(args.train_set), dataset=args.dataset)
    dataset_val = OWDetection(args, args.data_root, image_set=args.test_set, dataset=args.dataset,
                              transforms=make_coco_transforms(args.test_set))

    print(args.train_set)
    print(args.test_set)
    print(dataset_train)
    print(dataset_val)

    return dataset_train, dataset_val


# 定义一个函数用于生成一个丰富样本集（feature-tuning dataset）
def create_ft_dataset(args, image_sorted_scores):
    # 输出发现的图像数量
    print(f'found a total of {len(image_sorted_scores.keys())} images')
    # 确定文件保存路径
    tmp_dir = args.data_root + '/ImageSets/'+ "/" + args.exemplar_replay_dir + "/"
    # tmp_dir=args.data_root +'/ImageSets/'+args.exemplar_replay_dir+"/"

    # 初始化类别得分信息和每个类别的图像数量
    class_sorted_scores = {}
    imgs_per_class = {}
    # 对于所有要引入的新类别
    for i in range(args.PREV_INTRODUCED_CLS, args.CUR_INTRODUCED_CLS + args.PREV_INTRODUCED_CLS):
        # 对应的设置类别得分信息列表为空
        class_sorted_scores[str(i)] = []
        # 对应的图像数量也设置为 0
        imgs_per_class[str(i)] = []

    # 提取每个图像的标签和得分信息，并分别存储到对应的类别得分信息列表中
    for k, v in image_sorted_scores.items():
        for j in range(len(v['labels'])):
            label = str(v['labels'][j])
            class_sorted_scores[label].append(v['scores'][j])

    # 对于每个类别，确定保留哪些图像
    class_threshold = {}
    # 对于所有要引入的新类别
    for i in range(args.PREV_INTRODUCED_CLS, args.CUR_INTRODUCED_CLS + args.PREV_INTRODUCED_CLS):
        # 获取当前类别的得分列表
        tmp = np.array(class_sorted_scores[str(i)])
        # 对得分列表排序
        tmp.sort()
        # 将排序后的得分列表转为 PyTorch Tensor 类型
        tmp = torch.Tensor(tmp)
        # 如果当前类别的得分列表长度不足 args.num_inst_per_class 张，则将所有图像都保留下来
        if len(tmp) > args.num_inst_per_class and not args.exemplar_replay_random:
            # 计算当前类别的阈值，只保留得分在该阈值范围内的图像
            max_val = tmp[-args.num_inst_per_class // 2]
            min_val = tmp[args.num_inst_per_class // 2]
        else:
            # 如果当前类别的得分列表长度不足 args.num_inst_per_class 张，或者启用了随机样本复现，则将所有图像都保留下来
            if args.exemplar_replay_random:
                print('using random exemplar selection')
            else:
                print(f'only found {len(tmp)} imgs in class {i}')
            max_val = tmp.min()
            min_val = tmp.max()

        # 将当前类别的阈值保存到类别阈值字典中
        class_threshold[str(i)] = (min_val, max_val)

    # 初始化要保存的图像列表
    save_imgs = []
    # 遍历所有图像以及对应的标签和得分信息
    for k, v in image_sorted_scores.items():
        for j in range(len(v['labels'])):
            label = str(v['labels'][j])
            # 如果当前图像的得分低于该类别保留的最小得分或高于该类别保留的最大得分，且该类别已经保留的图像数量不足 args.num_inst_per_class 张，则将该图像保存在列表中
            if (v['scores'][j] <= class_threshold[label][0].numpy() or v['scores'][j] >= class_threshold[label][
                1].numpy()) and (len(imgs_per_class[label]) <= args.num_inst_per_class + 2):
                save_imgs.append(k)
                imgs_per_class[label].append(k)

    # 输出计算出的保留图像数量
    print(f'found {len(np.unique(save_imgs))} images in run')
    # 如果之前已经有丰富样本集文件存在，则将新的图像添加到已有文件中
    if len(args.exemplar_replay_prev_file) > 0:
        previous_ft = open(tmp_dir + args.exemplar_replay_prev_file, 'r').read().splitlines()
        save_imgs += previous_ft

    # 将所有保存的图像路径去重并随机排序
    save_imgs = np.unique(save_imgs)
    np.random.shuffle(save_imgs)
    # 如果保存的图像数量超过了预设的最大数量，则截取前 args.exemplar_replay_max_length 张图像
    if len(save_imgs) > args.exemplar_replay_max_length:
        save_imgs = save_imgs[:args.exemplar_replay_max_length]

    # 确保目标目录存在
    os.makedirs(tmp_dir, exist_ok=True)
    # 将保存的图像路径写入到新的丰富样本集文件中
    with open(tmp_dir + args.exemplar_replay_cur_file, 'w') as f:
        for line in save_imgs:
            f.write(line)
            f.write('\n')
    # 返回保存的所有图像路径
    return


if __name__ == '__main__':
    parser = argparse.ArgumentParser('Deformable DETR training and evaluation script', parents=[get_args_parser()])
    args = parser.parse_args()
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    main(args)