#!/usr/bin/env bash

echo running training of prob-detr, M-OWODB dataset

set -x

EXP_DIR=exps/32_jieou_relation101
PY_ARGS=${@:1}
WANDB_NAME=PROB_32_jieou_relation101

python -u 32.py \
   --output_dir "${EXP_DIR}/t1" --dataset logo --PREV_INTRODUCED_CLS 0 --CUR_INTRODUCED_CLS 8\
    --train_set 't1_train' --test_set 'all_test' --epochs 236\
    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
    --wandb_name "${WANDB_NAME}_t1" --exemplar_replay_selection --exemplar_replay_max_length 32\
    --exemplar_replay_dir ${WANDB_NAME} --exemplar_replay_cur_file "learned_owod_t1_ft.txt"\
    ${PY_ARGS}
    


#PY_ARGS=${@:1}
#python -u 32.py \
#    --output_dir "${EXP_DIR}/t2" --dataset logo --PREV_INTRODUCED_CLS 8 --CUR_INTRODUCED_CLS 8\
#    --train_set 't2_train' --test_set 'all_test' --epochs 169\
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3 --freeze_prob_model\
#    --wandb_name "${WANDB_NAME}_t2"\
#    --exemplar_replay_selection --exemplar_replay_max_length 61 --exemplar_replay_dir ${WANDB_NAME}\
#    --exemplar_replay_prev_file "learned_owod_t1_ft.txt" --exemplar_replay_cur_file "learned_owod_t2_ft.txt"\
#    --pretrain "${EXP_DIR}/t1/checkpoint0158.pth" --lr 8e-6\
#    ${PY_ARGS}
    

PY_ARGS=${@:1}
python -u 32.py \
    --output_dir "${EXP_DIR}/t2_ft" --dataset logo --PREV_INTRODUCED_CLS 8 --CUR_INTRODUCED_CLS 8 \
    --train_set "${WANDB_NAME}/learned_owod_t2_ft" --test_set 'all_test' --epochs 456 --lr_drop 161 \
    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
    --wandb_name "${WANDB_NAME}_t2_ft"
#    --pretrain "${EXP_DIR}/t2/checkpoint.pth"\
    ${PY_ARGS}
    
    
#PY_ARGS=${@:1}
#python -u 321.py \
#    --output_dir "${EXP_DIR}/t3" --dataset logo --PREV_INTRODUCED_CLS 16 --CUR_INTRODUCED_CLS 8\
#    --train_set 't3_train' --test_set 'all_test' --epochs 375\
#    --model_type 'prob' --obj_loss_coef 8e-4 --freeze_prob_model --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t3"\
#    --exemplar_replay_selection --exemplar_replay_max_length 85 --exemplar_replay_dir ${WANDB_NAME}\
#    --exemplar_replay_prev_file "learned_owod_t2_ft.txt" --exemplar_replay_cur_file "learned_owod_t3_ft.txt"\
#    --pretrain "${EXP_DIR}/t2_ft/checkpoint0364.pth" --lr 8e-6 \
#    ${PY_ARGS}
    
    
#PY_ARGS=${@:1}
#python -u 321.py \
#    --output_dir "${EXP_DIR}/t3_ft" --dataset logo --PREV_INTRODUCED_CLS 16 --CUR_INTRODUCED_CLS 8 \
#    --train_set "${WANDB_NAME}/learned_owod_t3_ft" --test_set 'all_test' --epochs 497 --lr_drop 115\
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t3_ft"\
#    --pretrain "${EXP_DIR}/t3_ft/checkpoint0496.pth"\
#    ${PY_ARGS}
    
    
#PY_ARGS=${@:1}
#python -u 321.py \
#    --output_dir "${EXP_DIR}/t4" --dataset logo --PREV_INTRODUCED_CLS 24 --CUR_INTRODUCED_CLS 8\
#    --model_type 'prob' --obj_loss_coef 8e-4 --freeze_prob_model --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t4"\
#    --exemplar_replay_selection --exemplar_replay_max_length 130 --exemplar_replay_dir ${WANDB_NAME}\
#    --exemplar_replay_prev_file "learned_owod_t3_ft.txt" --exemplar_replay_cur_file "learned_owod_t4_ft.txt"\
#    --pretrain "${EXP_DIR}/t3_ft/checkpoint0496.pth" --lr 8e-6\
#    ${PY_ARGS}
    
    
PY_ARGS=${@:1}
#python -u 321.py \
    --output_dir "${EXP_DIR}/t4_ft" --dataset logo --PREV_INTRODUCED_CLS 24 --CUR_INTRODUCED_CLS 8\
    --train_set "${WANDB_NAME}/learned_owod_t4_ft" --test_set 'all_test' --epochs 691 --lr_drop 140\
    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
    --wandb_name "${WANDB_NAME}_t4_ft"
#    --pretrain "${EXP_DIR}/t4/checkpoint.pth" \
    ${PY_ARGS}