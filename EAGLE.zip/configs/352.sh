#!/usr/bin/env bash

echo running training of prob-detr, M-OWODB dataset

set -x

EXP_DIR=exps/352_zuijieou
PY_ARGS=${@:1}
WANDB_NAME=PROB_352_zuijieou

#python -u 352.py \
#   --output_dir "${EXP_DIR}/t1" --dataset logo --PREV_INTRODUCED_CLS 0 --CUR_INTRODUCED_CLS 88\
#   --train_set 't1_train' --test_set 'all_test' --epochs 106\
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
#    --backbone 'dino_resnet50' \
#    --wandb_name "${WANDB_NAME}_t1"\
#    --exemplar_replay_selection --exemplar_replay_max_length 319\
#    --exemplar_replay_dir ${WANDB_NAME} --exemplar_replay_cur_file "learned_owod_t1_ft.txt"\
#    --pretrain "${EXP_DIR}/t1/checkpoint0105.pth"\
#    ${PY_ARGS}   


#PY_ARGS=${@:1}
#python -u 352.py \
#    --output_dir "${EXP_DIR}/t2" --dataset logo --PREV_INTRODUCED_CLS 88 --CUR_INTRODUCED_CLS 88\
#    --train_set 't2_train' --test_set 'all_test' --epochs 116\
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3 --freeze_prob_model\
#    --wandb_name "${WANDB_NAME}_t2"\
#    --exemplar_replay_selection --exemplar_replay_max_length 648 --exemplar_replay_dir ${WANDB_NAME}\
#    --exemplar_replay_prev_file "learned_owod_t1_ft.txt" --exemplar_replay_cur_file "learned_owod_t2_ft.txt"\
#    --pretrain "${EXP_DIR}/t2/checkpoint.pth" --lr 8e-6\ 
#    ${PY_ARGS}
    

#PY_ARGS=${@:1}
#python -u 352.py \
#    --output_dir "${EXP_DIR}/t2_ft" --dataset logo --PREV_INTRODUCED_CLS 88 --CUR_INTRODUCED_CLS 88 \
#    --train_set "${WANDB_NAME}/learned_owod_t2_ft" --test_set 'all_test' --epochs 271 --lr_drop 89 \
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t2_ft"\
#    --pretrain "${EXP_DIR}/t2/checkpoint.pth"\
#    ${PY_ARGS}
    
    
#PY_ARGS=${@:1}
#python -u 352.py \
#    --output_dir "${EXP_DIR}/t3" --dataset logo --PREV_INTRODUCED_CLS 176 --CUR_INTRODUCED_CLS 88\
#    --train_set 't3_train' --test_set 'all_test' --epochs 236\
#    --model_type 'prob' --obj_loss_coef 8e-4 --freeze_prob_model --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t3"\
#    --exemplar_replay_selection --exemplar_replay_max_length 992 --exemplar_replay_dir ${WANDB_NAME}\
#    --exemplar_replay_prev_file "learned_owod_t2_ft.txt" --exemplar_replay_cur_file "learned_owod_t3_ft.txt"\
#    --pretrain "${EXP_DIR}/t2_ft/checkpoint0225.pth" --lr 8e-6 \
#    ${PY_ARGS}
    
    
#PY_ARGS=${@:1}
#python -u 352.py \
#    --output_dir "${EXP_DIR}/t3_ft" --dataset logo --PREV_INTRODUCED_CLS 176 --CUR_INTRODUCED_CLS 88 \
#    --train_set "${WANDB_NAME}/learned_owod_t3_ft" --test_set 'all_test' --epochs 366 --lr_drop 74\
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t3_ft"
#    --pretrain "${EXP_DIR}/t3/checkpoint.pth"\
#    ${PY_ARGS}
    
    
#PY_ARGS=${@:1}
#python -u 352.py \
#    --output_dir "${EXP_DIR}/t4" --dataset logo --PREV_INTRODUCED_CLS 264 --CUR_INTRODUCED_CLS 88\
#    --train_set 't4_train' --test_set 'all_test' --epochs 326  --lr 8e-6\
#    --model_type 'prob' --obj_loss_coef 8e-4 --freeze_prob_model --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t4"\
#    --exemplar_replay_selection --exemplar_replay_max_length 1323 --exemplar_replay_dir ${WANDB_NAME}\
#    --exemplar_replay_prev_file "learned_owod_t3_ft.txt" --exemplar_replay_cur_file "learned_owod_t4_ft.txt"\
#    --pretrain "${EXP_DIR}/t3_ft/checkpoint0315.pth"\
#    ${PY_ARGS}
    
    
PY_ARGS=${@:1}
python -u 352.py \
    --output_dir "${EXP_DIR}/t4_ft" --dataset logo --PREV_INTRODUCED_CLS 264 --CUR_INTRODUCED_CLS 88\
    --train_set "${WANDB_NAME}/learned_owod_t4_ft" --test_set 'all_test' --epochs 416 --lr_drop 45\
    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
    --wandb_name "${WANDB_NAME}_t4_ft"
#    --pretrain "${EXP_DIR}/t4/checkpoint.pth" \
    ${PY_ARGS}