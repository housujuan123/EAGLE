#!/usr/bin/env bash

echo running training of prob-detr, M-OWODB dataset

set -x

EXP_DIR=exps/MOWODB/PROB
PY_ARGS=${@:1}
WANDB_NAME=PROB_V1

#python -u main.py \
#    --output_dir "${EXP_DIR}/t1" --dataset TOWOD --PREV_INTRODUCED_CLS 0 --CUR_INTRODUCED_CLS 20\
#    --train_set 't1_train' --test_set 'all_task_test' --epochs 66\
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t1" --exemplar_replay_selection --exemplar_replay_max_length 850\
#    --exemplar_replay_dir ${WANDB_NAME} --exemplar_replay_cur_file "learned_owod_t1_ft.txt"
#    --pretrain "${EXP_DIR}/t1/checkpoint0065.pth"\
#    ${PY_ARGS}
    

#PY_ARGS=${@:1}
#python -u main.py \
#    --output_dir "${EXP_DIR}/t2" --dataset TOWOD --PREV_INTRODUCED_CLS 20 --CUR_INTRODUCED_CLS 20\
#    --train_set 't2_train' --test_set 'all_task_test' --epochs 76\
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3 --freeze_prob_model\
#    --wandb_name "${WANDB_NAME}_t2"\
#    --exemplar_replay_selection --exemplar_replay_max_length 1743 --exemplar_replay_dir ${WANDB_NAME}\
#    --exemplar_replay_prev_file "learned_owod_t1_ft.txt" --exemplar_replay_cur_file "learned_owod_t2_ft.txt"\
#    --pretrain "${EXP_DIR}/t1/checkpoint0065.pth" --lr 8e-6\
#    ${PY_ARGS}
    

#PY_ARGS=${@:1}
#python -u main.py \
#    --output_dir "${EXP_DIR}/t2_ft" --dataset TOWOD --PREV_INTRODUCED_CLS 20 --CUR_INTRODUCED_CLS 20 \
#    --train_set "${WANDB_NAME}/learned_owod_t2_ft" --test_set 'all_task_test' --epochs 131 --lr_drop 29\
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
#   --wandb_name "${WANDB_NAME}_t2_ft"
#    --pretrain "${EXP_DIR}/t2/checkpoint.pth"\
#    ${PY_ARGS}
    
    
#PY_ARGS=${@:1}
#python -u main.py \
#    --output_dir "${EXP_DIR}/t3" --dataset TOWOD --PREV_INTRODUCED_CLS 40 --CUR_INTRODUCED_CLS 20\
#    --train_set 't3_train' --test_set 'all_task_test' --epochs 121\
#    --model_type 'prob' --obj_loss_coef 8e-4 --freeze_prob_model --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t3"\
#    --exemplar_replay_selection --exemplar_replay_max_length 2361 --exemplar_replay_dir ${WANDB_NAME}\
#    --exemplar_replay_prev_file "learned_owod_t2_ft.txt" --exemplar_replay_cur_file "learned_owod_t3_ft.txt"\
#    --pretrain "${EXP_DIR}/t2_ft/checkpoint0110.pth" --lr 8e-6 \
#    ${PY_ARGS}
    
    
#PY_ARGS=${@:1}
#python -u main.py \
#    --output_dir "${EXP_DIR}/t3_ft" --dataset TOWOD --PREV_INTRODUCED_CLS 40 --CUR_INTRODUCED_CLS 20 \
#    --train_set "${WANDB_NAME}/learned_owod_t3_ft" --test_set 'all_task_test' --epochs 161 --lr_drop 20\
#    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t3_ft"
#    --pretrain "${EXP_DIR}/t3/checkpoint.pth"\
#    ${PY_ARGS}
    
    
#PY_ARGS=${@:1}
#python -u main.py \
#    --output_dir "${EXP_DIR}/t4" --dataset TOWOD --PREV_INTRODUCED_CLS 60 --CUR_INTRODUCED_CLS 20\
#    --train_set 't4_train' --test_set 'all_task_test' --epochs 156 \
#    --model_type 'prob' --obj_loss_coef 8e-4 --freeze_prob_model --obj_temp 1.3\
#    --wandb_name "${WANDB_NAME}_t4"\
#    --exemplar_replay_selection --exemplar_replay_max_length 2749 --exemplar_replay_dir ${WANDB_NAME}\
#    --exemplar_replay_prev_file "learned_owod_t3_ft.txt" --exemplar_replay_cur_file "learned_owod_t4_ft.txt"\
#    --pretrain "${EXP_DIR}/t3_ft/checkpoint0145.pth" --lr 8e-6\
#    ${PY_ARGS}
    #--num_inst_per_class 40\    
    
PY_ARGS=${@:1}
python -u main.py \
    --output_dir "${EXP_DIR}/t4_ft" --dataset TOWOD --PREV_INTRODUCED_CLS 60 --CUR_INTRODUCED_CLS 20\
    --train_set "${WANDB_NAME}/learned_owod_t4_ft" --test_set 'all_task_test' --epochs 216 --lr_drop 31\
    --model_type 'prob' --obj_loss_coef 8e-4 --obj_temp 1.3\
    --wandb_name "${WANDB_NAME}_t4_ft"
#    --pretrain "${EXP_DIR}/t4/checkpoint.pth" \
    ${PY_ARGS}