#!/bin/bash

#GPUS_PER_NODE=2 ./tools/run_dist_launch.sh 2 configs/S.sh
#bash configs/Openlogo.sh
bash configs/321.sh