# ------------------------------------------------------------------------
# Deformable DETR
# Copyright (c) 2020 SenseTime. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------
# Modified from DETR (https://github.com/facebookresearch/detr)
# Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved
# -----------------------------------------------------------------------
"""
Deformable DETR model and criterion classes.
"""
import torch
import torch.nn.functional as F
from torch import nn
import math

from util import box_ops
from util.misc import (NestedTensor, nested_tensor_from_tensor_list,
                       accuracy, get_world_size, interpolate,
                       is_dist_avail_and_initialized, inverse_sigmoid)

from .backbone import build_backbone
from .matcher import build_matcher
from .segmentation import (DETRsegm, PostProcessPanoptic, PostProcessSegm,
                           dice_loss)
from .segmentation import sigmoid_focal_loss as seg_sigmoid_focal_loss
from .deformable_transformer import build_deforamble_transformer
import copy
from torchvision.ops.boxes import box_area
#这是一个用于复制指定模块多次的函数。该函数接受两个参数：要复制的模块（module）和复制的数量（N）。
# 它使用nn.ModuleList将指定模块的多个副本打包为一个模块列表，并返回该列表。在此过程中，copy.deepcopy()被
# 用于创建模块的副本，以避免对原始模块或其任何参数进行修改。
#这个函数在创建需要多次使用相同的模块时非常有用。通过复制模块可以减少代码的冗余，提高代码的可读性。
def _get_clones(module, N):
    return nn.ModuleList([copy.deepcopy(module) for i in range(N)])
def box_iou(boxes1, boxes2):
    area1 = box_area(boxes1)
    area2 = box_area(boxes2)

    lt = torch.max(boxes1[:, None, :2], boxes2[:, :2])  # [N,M,2]
    rb = torch.min(boxes1[:, None, 2:], boxes2[:, 2:])  # [N,M,2]

    wh = (rb - lt).clamp(min=0)  # [N,M,2]
    inter = wh[:, :, 0] * wh[:, :, 1]  # [N,M]

    union = area1[:, None] + area2 - inter

    iou = inter / union
    return iou, union
def box_cxcywh_to_xyxy(x):
    x_c, y_c, w, h = x.unbind(-1)
    b = [(x_c - 0.5 * w), (y_c - 0.5 * h),
         (x_c + 0.5 * w), (y_c + 0.5 * h)]
    return torch.stack(b, dim=-1)
def _get_clones(module, N):
    return nn.ModuleList([copy.deepcopy(module) for i in range(N)])
def generalized_box_iou(boxes1, boxes2):
    """
    Generalized IoU from https://giou.stanford.edu/

    The boxes should be in [x0, y0, x1, y1] format

    Returns a [N, M] pairwise matrix, where N = len(boxes1)
    and M = len(boxes2)
    """
    # degenerate boxes gives inf / nan results
    # so do an early check
    assert (boxes1[:, 2:] >= boxes1[:, :2]).all()
    assert (boxes2[:, 2:] >= boxes2[:, :2]).all()
    iou, union = box_iou(boxes1, boxes2)

    lt = torch.min(boxes1[:, None, :2], boxes2[:, :2])
    rb = torch.max(boxes1[:, None, 2:], boxes2[:, 2:])

    wh = (rb - lt).clamp(min=0)  # [N,M,2]
    area = wh[:, :, 0] * wh[:, :, 1]

    return iou - (area - union) / area
#在函数中，先使用Sigmoid函数将输入映射到概率空间，然后定义一个类别权重张量W，所有类别的初始权重都为1，
# 但是将空类别（背景类别）的权重设为empty_weight。接着利用二分类交叉熵计算初始损失，并使用W进行加权处理，
# 得到新的损失值。最后，使用modulating factor公式计算最终损失，并使用alpha来平衡正负样本之间的权重，
# 最终对所有的box的损失值求平均并除以num_boxes，得到最终的loss值。
def sigmoid_focal_loss(inputs, targets, num_boxes, alpha: float = 0.25, gamma: float = 2, num_classes: int = 81,
                       empty_weight: float = 0.1):
    """
    Loss used in RetinaNet for dense detection: https://arxiv.org/abs/1708.02002.
    Args:
        inputs: A float tensor of arbitrary shape.
                The predictions for each example.
        targets: A float tensor with the same shape as inputs. Stores the binary
                 classification label for each element in inputs
                (0 for the negative class and 1 for the positive class).
        alpha: (optional) Weighting factor in range (0,1) to balance
                positive vs negative examples. Default = -1 (no weighting).
        gamma: Exponent of the modulating factor (1 - p_t) to
               balance easy vs hard examples.
        num_classes: 类别总数
        empty_weight: 空类别（背景）的权重
    Returns:
        Loss tensor
    """
    # 对输入进行Sigmoid函数映射得到概率值
    prob = inputs.sigmoid()
    # 初始化权重因子W，所有类别的初始权重都为1，附加空类别的权重设为empty_weight
    W = torch.ones(num_classes, dtype=prob.dtype, layout=prob.layout, device=prob.device)
    W[-1] = empty_weight

    # 计算二分类交叉熵损失，并使用权重W进行加权
    ce_loss = F.binary_cross_entropy_with_logits(inputs, targets, reduction="none", weight=W)

    # 计算modulating factor p_t并进一步计算损失
    p_t = prob * targets + (1 - prob) * (1 - targets)
    loss = ce_loss * ((1 - p_t) ** gamma)

    # 如果指定了alpha，则使用alpha进行平衡处理
    if alpha >= 0:
        alpha_t = alpha * targets + (1 - alpha) * (1 - targets)
        loss = alpha_t * loss

    # 对所有的box的损失值求平均并除以num_boxes，得到最终的loss值
    return loss.mean(1).sum() / num_boxes

# 求objectness的概率值
class ProbObjectnessHead(nn.Module):
    def __init__(self, hidden_dim):
        super().__init__()
        # 定义一个展平层，将输入张量展平为二维张量（第0维和1维为batch维度）
        self.flatten = nn.Flatten(0,1)
        # 定义一个Batch Normalization层，用于对展平后的输入张量进行归一化处理
        self.objectness_bn = nn.BatchNorm1d(hidden_dim, affine=False)

    def freeze_prob_model(self):
        # 调用eval函数冻结概率模型
        self.objectness_bn.eval()

    def forward(self, x):
        # 使用flatten函数将输入张量x展平为二维张量
        out = self.flatten(x)
        # 将展平后的输入张量通过BN层进行归一化处理，并unflatten为原始形状
        out = self.objectness_bn(out).unflatten(0, x.shape[:2])
        # 计算L2范数的平方，并返回结果作为objectness的概率值
        return out.norm(dim=-1) ** 2
    
    
class FullProbObjectnessHead(nn.Module):
    #初始化全局目标置信度估计模块。其中 hidden_dim 表示每个隐藏层的维数，device 表示要在哪个设备上执行。
    def __init__(self, hidden_dim=256, device='cpu'):
        super().__init__()
        self.flatten = nn.Flatten(0, 1)
        self.momentum = 0.1
        self.obj_mean=nn.Parameter(torch.ones(hidden_dim, device=device), requires_grad=False)
        self.obj_cov=nn.Parameter(torch.eye(hidden_dim, device=device), requires_grad=False)
        self.inv_obj_cov=nn.Parameter(torch.eye(hidden_dim, device=device), requires_grad=False)
        self.device=device
        self.hidden_dim=hidden_dim
    #更新当前模型的参数，即参考向量、协方差矩阵等等。其中 x 是一个输入张量。
    def update_params(self,x):
        out=self.flatten(x).detach()
        obj_mean=out.mean(dim=0)
        obj_cov=torch.cov(out.T)
        self.obj_mean.data = self.obj_mean*(1-self.momentum) + self.momentum*obj_mean
        self.obj_cov.data = self.obj_cov*(1-self.momentum) + self.momentum*obj_cov
        return

    #更新当前模型的逆协方差矩阵。
    def update_icov(self):
        self.inv_obj_cov.data = torch.pinverse(self.obj_cov.detach().cpu(), rcond=1e-6).to(self.device)
        return
     #马氏距离
    def mahalanobis(self, x):
        # 展平 x 张量
        out = self.flatten(x)
        # 计算输入向量 out 与参考向量 obj_mean 之间的差值
        delta = out - self.obj_mean
        # 利用参考张量的协方差矩阵 inv_obj_cov 将输入向量 out 的差值 delta 进行缩放，得到马氏距离 m
        # 具体而言，利用 delta.T 和 inv_obj_cov 的点积得到一个数值，再对所有维度求和即可得到距离值 m
        m = (delta * torch.matmul(self.inv_obj_cov, delta.T).T).sum(dim=-1)
        # 将距离值 unflatten 回与输入张量 x 相同的形状，并返回最终结果
        return m.unflatten(0, x.shape[:2])
    #设置更新参数时的动量，即 momentum 的值。
    def set_momentum(self, m):
        self.momentum=m
        return
    #模型的前向计算过程。其中，如果当前模式为训练模式，则会调用 update_params 函数更新当前模型的参数；
    # 否则直接计算输入张量 x 与参考向量之间的马氏距离。
    def forward(self, x):
        if self.training:
            self.update_params(x)
        return self.mahalanobis(x)

class WeightedFusionModule(nn.Module):
    def __init__(self):
        super(WeightedFusionModule, self).__init__()
        # 定义权重参数
        self.weight1 = nn.Parameter(torch.Tensor(1))
        self.weight2 = nn.Parameter(torch.Tensor(1))
        # 初始化权重参数
        nn.init.uniform_(self.weight1)
        nn.init.uniform_(self.weight2)

    def forward(self, tensor1, tensor2):
        # 将权重参数应用到张量上
        weighted_tensor1 = tensor1 * self.weight1
        weighted_tensor2 = tensor2 * self.weight2
        # 将加权后的张量相加
        fused_tensor = weighted_tensor1 + weighted_tensor2
        return fused_tensor
class DeformableDETR(nn.Module):
    """ This is the Deformable DETR module that performs object detection """
    def __init__(self, backbone, transformer, num_classes, num_queries, num_feature_levels,
                 aux_loss=True, with_box_refine=False, two_stage=False):
        """ Initializes the model.
        Parameters:
            backbone: torch module of the backbone to be used. See backbone.py
            transformer: torch module of the transformer architecture. See transformer.py
            num_classes: number of object classes
            num_queries: number of object queries, ie detection slot. This is the maximal number of objects
                         DETR can detect in a single image. For COCO, we recommend 100 queries.
            aux_loss: True if auxiliary decoding losses (loss at each decoder layer) are to be used.
            with_box_refine: iterative bounding box refinement
            two_stage: two-stage Deformable DETR
        """
        super().__init__()
        self.num_queries = num_queries
        self.transformer = transformer
        hidden_dim = transformer.d_model
        
        self.class_embed = nn.Linear(hidden_dim, num_classes)
        self.bbox_embed = MLP(hidden_dim, hidden_dim, 4, 3)
        self.prob_obj_head = ProbObjectnessHead(hidden_dim)

        self.num_feature_levels = num_feature_levels
        if not two_stage:
            self.query_embed = nn.Embedding(num_queries, hidden_dim*2)
        if num_feature_levels > 1:
            num_backbone_outs = len(backbone.strides)
            input_proj_list = []
            for _ in range(num_backbone_outs):
                in_channels = backbone.num_channels[_]
                input_proj_list.append(nn.Sequential(
                    nn.Conv2d(in_channels, hidden_dim, kernel_size=1),
                    nn.GroupNorm(32, hidden_dim),
                ))
            for _ in range(num_feature_levels - num_backbone_outs):
                input_proj_list.append(nn.Sequential(
                    nn.Conv2d(in_channels, hidden_dim, kernel_size=3, stride=2, padding=1),
                    nn.GroupNorm(32, hidden_dim),
                ))
                in_channels = hidden_dim
            self.input_proj = nn.ModuleList(input_proj_list)
        else:
            self.input_proj = nn.ModuleList([
                nn.Sequential(
                    nn.Conv2d(backbone.num_channels[0], hidden_dim, kernel_size=1),
                    nn.GroupNorm(32, hidden_dim),
                )])
        self.backbone = backbone
        self.aux_loss = aux_loss
        self.with_box_refine = with_box_refine
        self.two_stage = two_stage

        prior_prob = 0.01
        bias_value = -math.log((1 - prior_prob) / prior_prob)
        self.class_embed.bias.data = torch.ones(num_classes) * bias_value
        nn.init.constant_(self.bbox_embed.layers[-1].weight.data, 0)
        nn.init.constant_(self.bbox_embed.layers[-1].bias.data, 0)
        for proj in self.input_proj:
            nn.init.xavier_uniform_(proj[0].weight, gain=1)
            nn.init.constant_(proj[0].bias, 0)

        # if two-stage, the last class_embed and bbox_embed is for region proposal generation
        num_pred = (transformer.local_decoder.num_layers + 1) if two_stage else transformer.local_decoder.num_layers

        if with_box_refine:
            self.class_embed = _get_clones(self.class_embed, num_pred)
            self.bbox_embed = _get_clones(self.bbox_embed, num_pred)
            self.prob_obj_head =  _get_clones(self.prob_obj_head, num_pred)
            nn.init.constant_(self.bbox_embed[0].layers[-1].bias.data[2:], -2.0)
            # hack implementation for iterative bounding box refinement
            self.transformer.local_decoder.bbox_embed = self.bbox_embed        
        else:
            nn.init.constant_(self.bbox_embed.layers[-1].bias.data[2:], -2.0)
            self.class_embed = nn.ModuleList([self.class_embed for _ in range(num_pred)])
            self.bbox_embed = nn.ModuleList([self.bbox_embed for _ in range(num_pred)])
            self.prob_obj_head = nn.ModuleList([self.prob_obj_head for _ in range(num_pred)])
            self.transformer.local_decoder.bbox_embed = None
        if two_stage:
            # hack implementation for two-stage
            self.transformer.class_decoder.class_embed = self.class_embed
            for box_embed in self.bbox_embed:
                nn.init.constant_(box_embed.layers[-1].bias.data[2:], 0.0)

    def forward(self, samples: NestedTensor):
        # NestedTensor 包含样本图片和对应的标记掩码
        # 如果输入不是 NestedTensor 类型，则将其转换成 NestedTensor 类型
        if not isinstance(samples, NestedTensor):
            samples = nested_tensor_from_tensor_list(samples)

        # Backbone 提取特征和位置编码 pos
        features, pos = self.backbone(samples)

        srcs = []
        masks = []
        for l, feat in enumerate(features):
            # 将 feature decompose 成 src 和 mask
            src, mask = feat.decompose()
            # 对 src 应用 input projection
            srcs.append(self.input_proj[l](src))
            masks.append(mask)
            # mask 不应为空
            assert mask is not None
        # 如果 feature levels 的数量小于 num_feature_levels，就需要从已有的 feature levels 补全到 num_feature_levels
        if self.num_feature_levels > len(srcs):
            _len_srcs = len(srcs)
            for l in range(_len_srcs, self.num_feature_levels):
                if l == _len_srcs:
                    # 对最后一个 feature level 应用 input projection
                    src = self.input_proj[l](features[-1].tensors)
                else:
                    # 对上一个 feature level 应用 input projection
                    src = self.input_proj[l](srcs[-1])
                # 将样本标记掩码 sample.mask 调整到与 src 相同大小，得到 mask
                m = samples.mask
                mask = F.interpolate(m[None].float(), size=src.shape[-2:]).to(torch.bool)[0]
                # 对 mask 应用 backbone 得到新的位置编码 pos_l，然后添加到 pos 中
                pos_l = self.backbone[1](NestedTensor(src, mask)).to(src.dtype)
                srcs.append(src)
                masks.append(mask)
                pos.append(pos_l)

        query_embeds = None
        # 如果不是 two-stage 模型，则初始化 query_embeds 为所有查询的嵌入向量
        if not self.two_stage:
            query_embeds = self.query_embed.weight
        # transformer 阶段
        local_hs, class_hs, init_reference, inter_references, enc_outputs_class, enc_outputs_coord_unact = self.transformer(srcs, masks,
                                                                                                            pos,query_embeds)                                                                                                  
 

        outputs_classes = []
        outputs_coords = []
        outputs_objectnesses = []
        

        for lvl in range(local_hs.shape[0]):
            if lvl == 0:
                reference = init_reference
            else:
                reference = inter_references[lvl - 1]
            
            reference = inverse_sigmoid(reference)
            tmp = self.bbox_embed[lvl](local_hs[lvl])
            
            if reference.shape[-1] == 4:
                tmp += reference
            else:
                assert reference.shape[-1] == 2
                tmp[..., :2] += reference
            outputs_coord = tmp.sigmoid()
            outputs_coords.append(outputs_coord)

        # identification decoder
        for lvl in range(class_hs.shape[0]):
            outputs_class = self.class_embed[lvl](class_hs[lvl])
            outputs_objectness = self.prob_obj_head[lvl](class_hs[lvl])
            outputs_classes.append(outputs_class)
            outputs_objectnesses.append(outputs_objectness)

        # 将每个 feature level 对应的结果拼接成一个输出 Tensor
        outputs_class = torch.stack(outputs_classes)
        outputs_coord = torch.stack(outputs_coords)
        outputs_objectness = torch.stack(outputs_objectnesses)

        # 构造输出字典 out，包含三个键值对：pred_logits、pred_boxes 和 pred_obj
        out = {'pred_logits': outputs_class[-1], 'pred_boxes': outputs_coord[-1], 'pred_obj': outputs_objectness[-1]}

        # 如果 aux_loss 为 True，则添加 aux_outputs 到输出字典中
        if self.aux_loss:
            out['aux_outputs'] = self._set_aux_loss(outputs_class, outputs_coord, outputs_objectness)

        # 如果模型是 two-stage，则返回 enc_outputs 代表 region proposals
        if self.two_stage:
            enc_outputs_coord = enc_outputs_coord_unact.sigmoid()
            out['enc_outputs'] = {'pred_logits': enc_outputs_class, 'pred_boxes': enc_outputs_coord}
        return out

    @torch.jit.unused
    def _set_aux_loss(self, outputs_class, outputs_coord, objectness):
        # this is a workaround to make torchscript happy, as torchscript
        # doesn't support dictionary with non-homogeneous values, such
        # as a dict having both a Tensor and a list.
        return [{'pred_logits': a, 'pred_obj': b, 'pred_boxes': c}
                for a, b, c in zip(outputs_class[:-1], objectness[:-1], outputs_coord[:-1])]


class SetCriterion(nn.Module):
    """ This class computes the loss for DETR.
    The process happens in two steps:
        1) we compute hungarian assignment between ground truth boxes and the outputs of the model
        2) we supervise each pair of matched ground-truth / prediction (supervise class and box)
    """
    def __init__(self, num_classes, matcher, weight_dict, losses, invalid_cls_logits, hidden_dim, focal_alpha=0.25, empty_weight=0.1,gamma = 2.0,GIoU_aware_class_loss = True):
        """ Create the criterion.
        Parameters:
            num_classes: number of object categories, omitting the special no-object category
            matcher: module able to compute a matching between targets and proposals
            weight_dict: dict containing as key the names of the losses and as values their relative weight.
            losses: list of all the losses to be applied. See get_loss for list of available losses.
            focal_alpha: alpha in Focal Loss
        """
        super().__init__()
        self.num_classes = num_classes
        self.matcher = matcher
        self.weight_dict = weight_dict
        self.losses = losses
        self.alpha = focal_alpha
        self.gamma = gamma
        
        self.empty_weight=empty_weight
        self.invalid_cls_logits = invalid_cls_logits
        self.min_obj=-hidden_dim*math.log(0.9)
        self.GIoU_aware_class_loss = GIoU_aware_class_loss
 
    def loss_labels(self, outputs, targets, indices, num_boxes, log=True):
        """Classification loss (NLL)
        targets dicts must contain the key "labels" containing a tensor of dim [nb_target_boxes]
        """
        assert 'pred_logits' in outputs  # 确认输入输出中包含预测 logits
        temp_src_logits = outputs['pred_logits'].clone()  # 克隆预测 logits 到临时变量
        temp_src_logits[:, :, self.invalid_cls_logits] = -10e10  # 处理掉无效类别的 logits
        src_logits = temp_src_logits  # 取得处理后的 logits

        idx = self._get_src_permutation_idx(indices)  # 获取 source image 中对应 target 中 bbox 的索引
        target_classes_o = torch.cat([t["labels"][J] for t, (_, J) in zip(targets, indices)])  # 构造 ground truth 的类别标签
#66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
        target_classes = torch.full(src_logits.shape[:2], self.num_classes-1, dtype=torch.int64,
                                    device=src_logits.device)  # 初始化全部标签为 num_classes-1
        target_classes[idx] = target_classes_o  # 将 ground truth 类别标签填充到对应位置上
        # 将 target_classes 转化为 one-hot 格式
        target_classes_onehot = torch.zeros([src_logits.shape[0], src_logits.shape[1], src_logits.shape[2]],
                                            dtype=src_logits.dtype, layout=src_logits.layout, device=src_logits.device)
        target_classes_onehot.scatter_(2, target_classes.unsqueeze(-1), 1)

        # 计算 Sigmoid focal loss
        loss_ce = sigmoid_focal_loss(src_logits, target_classes_onehot, num_boxes, alpha=self.alpha,
                                     num_classes=self.num_classes, empty_weight=self.empty_weight) * src_logits.shape[1]

        # 构造损失字典并添加 loss_ce 到其中
        losses = {'loss_ce': loss_ce}

        if log:
            # 计算分类错误率 class_error，并添加到损失字典中
            # TODO this should probably be a separate loss, not hacked in this one here
            losses['class_error'] = 100 - accuracy(src_logits[idx], target_classes_o)[0]

        return losses  # 返回损失字典
    """def loss_labels(self, outputs, targets, indices, num_boxes, log=True, GIoU_aware_class_loss = True):
        assert 'pred_logits' in outputs  # 确认输入输出中包含预测 logits
        temp_src_logits = outputs['pred_logits'].clone()  # 克隆预测 logits 到临时变量
        temp_src_logits[:, :, self.invalid_cls_logits] = -10e10  # 处理掉无效类别的 logits
        src_logits = temp_src_logits  # 取得处理后的 logits

        idx = self._get_src_permutation_idx(indices)  # 获取 source image 中对应 target 中 bbox 的索引
        target_classes_o = torch.cat([t["labels"][J] for t, (_, J) in zip(targets, indices)])  # 构造 ground truth 的类别标签
#66666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666
        target_classes = torch.full(src_logits.shape[:2], self.num_classes-1, dtype=torch.int64,
                                    device=src_logits.device)  # 初始化全部标签为 num_classes-1
        target_classes[idx] = target_classes_o  # 将 ground truth 类别标签填充到对应位置上
        # 将 target_classes 转化为 one-hot 格式
        target_classes_onehot = torch.zeros([src_logits.shape[0], src_logits.shape[1], src_logits.shape[2]],
                                            dtype=src_logits.dtype, layout=src_logits.layout, device=src_logits.device)
        target_classes_onehot.scatter_(2, target_classes.unsqueeze(-1), 1)
        loss_ce1 = sigmoid_focal_loss(src_logits, target_classes_onehot, num_boxes, alpha=self.alpha,
                                     num_classes=self.num_classes, empty_weight=self.empty_weight) * src_logits.shape[1] 
        if True:
           if GIoU_aware_class_loss:
                # get GIoU-aware classification target: t = (GIoU + 1) / 2

                # # get normed GIoU
                bs, n_query = outputs["pred_boxes"].shape[:2]
                out_bbox = outputs["pred_boxes"].flatten(0, 1)                # tensor shape: [bs * n_query, 4]
                tgt_bbox = torch.cat([v["boxes"] for v in targets])           # tensor shape: [gt number within a batch, 4]
                bbox_giou = generalized_box_iou(
                    box_cxcywh_to_xyxy(out_bbox), box_cxcywh_to_xyxy(tgt_bbox)
                )  
                pi = torch.acos(torch.zeros(1)).item() * 2   # 获取π的值
                bbox_giou_normed = (torch.atan(bbox_giou) / pi) + 0.5        # tensor shape: [bs * n_query, gt number within a batch]
                #bbox_giou_normed = (bbox_giou + 1) / 2.0
                #bbox_giou_normed = bbox_giou
                bbox_giou_normed = bbox_giou_normed.reshape(bs, n_query, -1)  # tensor shape: [bs, n_query, gt number within a batch]

                # # get matched gt indices: gt_indices
                for indices_idx, element in enumerate(indices):
                    if indices_idx == 0:
                        gt_indices = element[1]
                    else:
                        curr_length = gt_indices.shape[0]
                        gt_indices = torch.cat((gt_indices, element[1] + curr_length), dim=0)

                # # get the supervision with a shape of [bs, n_query, num_classes]
                class_supervision = torch.zeros(
                    [src_logits.shape[0], src_logits.shape[1]],
                    dtype=src_logits.dtype,
                    layout=src_logits.layout,
                    device=src_logits.device,
                )
                class_supervision[idx] = bbox_giou_normed[(idx[0], idx[1], gt_indices)] # idx[0]: batch idx; idx[1]: query idx; gt_indices: matched gt idx
                class_supervision = class_supervision.detach()
                target_classes_onehot_GIoU_aware = target_classes_onehot * class_supervision.unsqueeze(-1)

                # sigmoid_focal_loss supervised by target_classes_onehot_GIoU_aware
                src_prob = src_logits.sigmoid()

                #target_classes_onehot_GIoU_aware = torch.exp(-(2.097 * src_prob**2 + 1.413 * target_classes_onehot_GIoU_aware**2))
                #target_classes_onehot_GIoU_aware = 0.3*src_prob + 0.7*target_classes_onehot_GIoU_aware
                #target_classes_onehot_GIoU_aware = torch.exp(-0.5 * target_classes_onehot_GIoU_aware) + 0.1 * src_prob
                # # positive samples
                bce_loss_pos = F.binary_cross_entropy_with_logits(src_logits, target_classes_onehot_GIoU_aware, reduction="none") * target_classes_onehot
                p_t_pos = torch.abs(target_classes_onehot_GIoU_aware - src_prob * target_classes_onehot) ** self.gamma

                # # negative samples
                bce_loss_neg = F.binary_cross_entropy_with_logits(src_logits, target_classes_onehot, reduction="none") * (1 - target_classes_onehot)
                p_t_neg = torch.abs(src_prob * (1 - target_classes_onehot)) ** self.gamma

                # # total loss
                loss = p_t_pos * bce_loss_pos + p_t_neg * bce_loss_neg

                if self.alpha >= 0:
                    alpha_t = self.alpha * target_classes_onehot + (1 - self.alpha) * (1 - target_classes_onehot)
                    loss = alpha_t * loss

                loss_class = loss.mean(1).sum() / num_boxes
                loss_ce2 = loss_class * src_logits.shape[1]
          
           #else:
           #    loss_ce = sigmoid_focal_loss(src_logits, target_classes_onehot, num_boxes, alpha=self.alpha,
           #                          num_classes=self.num_classes, empty_weight=self.empty_weight) * src_logits.shape[1]
           
           loss_ce = 0.3*loss_ce2+0.7*loss_ce1
        ## 计算 Sigmoid focal loss
        #loss_ce = sigmoid_focal_loss(src_logits, target_classes_onehot, num_boxes, alpha=self.focal_alpha,
        #                             num_classes=self.num_classes, empty_weight=self.empty_weight) * src_logits.shape[1]

        # 构造损失字典并添加 loss_ce 到其中
        losses = {'loss_ce': loss_ce}

        if log:
            # 计算分类错误率 class_error，并添加到损失字典中
            # TODO this should probably be a separate loss, not hacked in this one here
            losses['class_error'] = 100 - accuracy(src_logits[idx], target_classes_o)[0]

        return losses  # 返回损失字典"""

    @torch.no_grad()
    def loss_cardinality(self, outputs, targets, indices, num_boxes):
        """ Compute the cardinality error, ie the absolute error in the number of predicted non-empty boxes
        This is not really a loss, it is intended for logging purposes only. It doesn't propagate gradients
        """
        pred_logits = outputs['pred_logits']
        device = pred_logits.device
        tgt_lengths = torch.as_tensor([len(v["labels"]) for v in targets], device=device)
        # Count the number of predictions that are NOT "no-object" (which is the last class)
        card_pred = (pred_logits.argmax(-1) != pred_logits.shape[-1] - 1).sum(1)
        card_err = F.l1_loss(card_pred.float(), tgt_lengths.float())
        losses = {'cardinality_error': card_err}
        return losses

    def loss_boxes(self, outputs, targets, indices, num_boxes):
        """Compute the losses related to the bounding boxes, the L1 regression loss and the GIoU loss
           targets dicts must contain the key "boxes" containing a tensor of dim [nb_target_boxes, 4]
           The target boxes are expected in format (center_x, center_y, h, w), normalized by the image size.
        """
        assert 'pred_boxes' in outputs
        idx = self._get_src_permutation_idx(indices)
        src_boxes = outputs['pred_boxes'][idx]
        target_boxes = torch.cat([t['boxes'][i] for t, (_, i) in zip(targets, indices)], dim=0)

        loss_bbox = F.l1_loss(src_boxes, target_boxes, reduction='none')

        losses = {}
        losses['loss_bbox'] = loss_bbox.sum() / num_boxes

        loss_giou = 1 - torch.diag(box_ops.generalized_box_iou(
            box_ops.box_cxcywh_to_xyxy(src_boxes),
            box_ops.box_cxcywh_to_xyxy(target_boxes)))
        losses['loss_giou'] = loss_giou.sum() / num_boxes
        return losses

    def loss_masks(self, outputs, targets, indices, num_boxes):
        """Compute the losses related to the masks: the focal loss and the dice loss.
           targets dicts must contain the key "masks" containing a tensor of dim [nb_target_boxes, h, w]
        """
        assert "pred_masks" in outputs

        src_idx = self._get_src_permutation_idx(indices)
        tgt_idx = self._get_tgt_permutation_idx(indices)

        src_masks = outputs["pred_masks"]

        # TODO use valid to mask invalid areas due to padding in loss
        target_masks, valid = nested_tensor_from_tensor_list([t["masks"] for t in targets]).decompose()
        target_masks = target_masks.to(src_masks)

        src_masks = src_masks[src_idx]
        # upsample predictions to the target size
        src_masks = interpolate(src_masks[:, None], size=target_masks.shape[-2:],
                                mode="bilinear", align_corners=False)
        src_masks = src_masks[:, 0].flatten(1)

        target_masks = target_masks[tgt_idx].flatten(1)

        losses = {
            "loss_mask": seg_sigmoid_focal_loss(src_masks, target_masks, num_boxes),
            "loss_dice": dice_loss(src_masks, target_masks, num_boxes),
        }
        return losses
    
    def loss_obj_likelihood(self, outputs, targets, indices, num_boxes):
        assert "pred_obj" in outputs
        idx = self._get_src_permutation_idx(indices)
        pred_obj = outputs["pred_obj"][idx]
        return  {'loss_obj_ll': torch.clamp(pred_obj, min=self.min_obj).sum()/ num_boxes}

    def _get_src_permutation_idx(self, indices):
        # permute predictions following indices
        batch_idx = torch.cat([torch.full_like(src, i) for i, (src, _) in enumerate(indices)])
        src_idx = torch.cat([src for (src, _) in indices])
        return batch_idx, src_idx

    def _get_tgt_permutation_idx(self, indices):
        # permute targets following indices
        batch_idx = torch.cat([torch.full_like(tgt, i) for i, (_, tgt) in enumerate(indices)])
        tgt_idx = torch.cat([tgt for (_, tgt) in indices])
        return batch_idx, tgt_idx

    def get_loss(self, loss, outputs, targets, indices, num_boxes, **kwargs):
        loss_map = {
            'labels': self.loss_labels,
            'cardinality': self.loss_cardinality,
            'boxes': self.loss_boxes,
            'obj_likelihood': self.loss_obj_likelihood,
            'masks': self.loss_masks
        }
        assert loss in loss_map, f'do you really want to compute {loss} loss?'
        return loss_map[loss](outputs, targets, indices, num_boxes, **kwargs)

    def forward(self, outputs, targets):
        """ This performs the loss computation.
        Parameters:
             outputs: dict of tensors, see the output specification of the model for the format
             targets: list of dicts, such that len(targets) == batch_size.
                      The expected keys in each dict depends on the losses applied, see each loss' doc
        """
        outputs_without_aux = {k: v for k, v in outputs.items() if k != 'aux_outputs' and k != 'enc_outputs' and k !='pred_obj'}

        # Retrieve the matching between the outputs of the last layer and the targets
        indices = self.matcher(outputs_without_aux, targets)

        # Compute the average number of target boxes accross all nodes, for normalization purposes
        num_boxes = sum(len(t["labels"]) for t in targets)
        num_boxes = torch.as_tensor([num_boxes], dtype=torch.float, device=next(iter(outputs.values())).device)
        if is_dist_avail_and_initialized():
            torch.distributed.all_reduce(num_boxes)
        num_boxes = torch.clamp(num_boxes / get_world_size(), min=1).item()

        # Compute all the requested losses
        losses = {}
        for loss in self.losses:
            kwargs = {}
            losses.update(self.get_loss(loss, outputs, targets, indices, num_boxes, **kwargs))

        # In case of auxiliary losses, we repeat this process with the output of each intermediate layer.
        if 'aux_outputs' in outputs:
            for i, aux_outputs in enumerate(outputs['aux_outputs']):
                indices = self.matcher(aux_outputs, targets)
                for loss in self.losses:
                    if loss == 'masks':
                        # Intermediate masks losses are too costly to compute, we ignore them.
                        continue
                    kwargs = {}
                    if loss == 'labels':
                        # Logging is enabled only for the last layer
                        kwargs['log'] = False
                    l_dict = self.get_loss(loss, aux_outputs, targets, indices, num_boxes, **kwargs)
                    l_dict = {k + f'_{i}': v for k, v in l_dict.items()}
                    losses.update(l_dict)

        if 'enc_outputs' in outputs:
            enc_outputs = outputs['enc_outputs']
            bin_targets = copy.deepcopy(targets)
            for bt in bin_targets:
                bt['labels'] = torch.zeros_like(bt['labels'])
            indices = self.matcher(enc_outputs, bin_targets)
            for loss in self.losses:
                if loss == 'masks':
                    # Intermediate masks losses are too costly to compute, we ignore them.
                    continue
                kwargs = {}
                if loss == 'labels':
                    # Logging is enabled only for the last layer
                    kwargs['log'] = False
                l_dict = self.get_loss(loss, enc_outputs, bin_targets, indices, num_boxes, **kwargs)
                l_dict = {k + f'_enc': v for k, v in l_dict.items()}
                losses.update(l_dict)

        return losses


class PostProcess(nn.Module):
    """ This module converts the model's output into the format expected by the coco api"""
    def __init__(self, invalid_cls_logits, temperature=1, pred_per_im=100):
        super().__init__()
        self.temperature=temperature
        self.invalid_cls_logits=invalid_cls_logits
        self.pred_per_im=pred_per_im

    @torch.no_grad()
    def forward(self, outputs, target_sizes):
        """ Perform the computation
        Parameters:
            outputs: raw outputs of the model
            target_sizes: tensor of dimension [batch_size x 2] containing the size of each images of the batch
                          For evaluation, this must be the original image size (before any data augmentation)
                          For visualization, this should be the image size after data augment, but before padding
        """        
        out_logits, pred_obj, out_bbox = outputs['pred_logits'], outputs['pred_obj'], outputs['pred_boxes']
        out_logits[:,:, self.invalid_cls_logits] = -10e10

        assert len(out_logits) == len(target_sizes)
        assert target_sizes.shape[1] == 2

        obj_prob = torch.exp(-self.temperature*pred_obj).unsqueeze(-1)
        #分类概率=对象性概率*分类概率
        prob = obj_prob*out_logits.sigmoid()

        topk_values, topk_indexes = torch.topk(prob.view(out_logits.shape[0], -1), self.pred_per_im, dim=1)
        scores = topk_values
        
        topk_boxes = topk_indexes // out_logits.shape[2]
        labels = topk_indexes % out_logits.shape[2]
        boxes = box_ops.box_cxcywh_to_xyxy(out_bbox)
        boxes = torch.gather(boxes, 1, topk_boxes.unsqueeze(-1).repeat(1,1,4))
        
        img_h, img_w = target_sizes.unbind(1)
        scale_fct = torch.stack([img_w, img_h, img_w, img_h], dim=1)
        boxes = boxes * scale_fct[:, None, :]
        results = [{'scores': s, 'labels': l, 'boxes': b} for s, l, b in zip(scores, labels, boxes)]
        return results


class MLP(nn.Module):
    """ Very simple multi-layer perceptron (also called FFN)"""

    def __init__(self, input_dim, hidden_dim, output_dim, num_layers):
        super().__init__()
        self.num_layers = num_layers
        h = [hidden_dim] * (num_layers - 1)
        self.layers = nn.ModuleList(nn.Linear(n, k) for n, k in zip([input_dim] + h, h + [output_dim]))

    def forward(self, x):
        for i, layer in enumerate(self.layers):
            x = F.relu(layer(x)) if i < self.num_layers - 1 else layer(x)
        return x
    
    
class ExemplarSelection(nn.Module):
    def __init__(self, args, num_classes, matcher, invalid_cls_logits, temperature=1):
        super().__init__()
        self.num_classes = num_classes
        self.matcher = matcher
        self.num_seen_classes = args.PREV_INTRODUCED_CLS + args.CUR_INTRODUCED_CLS
        self.invalid_cls_logits=invalid_cls_logits
        self.temperature=temperature
        print(f'running with exemplar_replay_selection')   
              
            
    def calc_energy_per_image(self, outputs, targets, indices):
        out_logits, pred_obj = outputs['pred_logits'], outputs['pred_obj']
        out_logits[:, :, self.invalid_cls_logits] = -10e10

        torch.exp(-self.temperature*pred_obj).unsqueeze(-1)
        logit_dist = torch.exp(-self.temperature*pred_obj).unsqueeze(-1)
        prob = logit_dist*out_logits.sigmoid()

        image_sorted_scores = {}
        """for i in range(len(targets)):
            image_sorted_scores[''.join([chr(int(c)) for c in targets[i]['org_image_id']])] = {'labels':targets[i]['labels'].cpu().numpy(),"scores": prob[i,indices[i][0],targets[i]['labels']].detach().cpu().numpy()}"""

        try:
            for i in range(len(targets)):
                image_id = ''.join([chr(int(c)) for c in targets[i]['org_image_id']])
                labels = targets[i]['labels'].cpu().numpy()
                scores = prob[i, indices[i][0], targets[i]['labels']].detach().cpu().numpy()
                image_sorted_scores[image_id] = {'labels': labels, 'scores': scores}
        except IndexError as e:
            print(f'IndexError occurred: {e}')
        
        return [image_sorted_scores]

    def forward(self, samples, outputs, targets):
        outputs_without_aux = {k: v for k, v in outputs.items() if k != 'aux_outputs' and k != 'enc_outputs' and k !='pred_obj'}
        indices = self.matcher(outputs_without_aux, targets)       
        return self.calc_energy_per_image(outputs, targets, indices)


def build(args):
    num_classes = args.num_classes
    invalid_cls_logits = list(range(args.PREV_INTRODUCED_CLS+args.CUR_INTRODUCED_CLS, num_classes-1))
    print("Invalid class range: " + str(invalid_cls_logits))
    
    device = torch.device(args.device)
    
    backbone = build_backbone(args)
    transformer = build_deforamble_transformer(args)
    
    model = DeformableDETR(
        backbone,
        transformer,
        num_classes=num_classes,
        num_queries=args.num_queries,
        num_feature_levels=args.num_feature_levels,
        aux_loss=args.aux_loss,
        with_box_refine=args.with_box_refine,
        two_stage=args.two_stage,
    )
    
    if args.masks:
        model = DETRsegm(model, freeze_detr=(args.frozen_weights is not None))
        
    matcher = build_matcher(args)
    weight_dict = {'loss_ce': args.cls_loss_coef, 'loss_bbox': args.bbox_loss_coef, 'loss_giou': args.giou_loss_coef, 'loss_obj_ll': args.obj_loss_coef}
    
    if args.masks:
        weight_dict["loss_mask"] = args.mask_loss_coef
        weight_dict["loss_dice"] = args.dice_loss_coef
    # TODO this is a hack
    if args.aux_loss:
        aux_weight_dict = {}
        for i in range(args.dec_layers - 1):
            aux_weight_dict.update({k + f'_{i}': v for k, v in weight_dict.items()})
        aux_weight_dict.update({k + f'_enc': v for k, v in weight_dict.items()})
        weight_dict.update(aux_weight_dict)

    losses = ['labels', 'boxes', 'cardinality','obj_likelihood']
    if args.masks:
        losses += ["masks"]

        
    criterion = SetCriterion(num_classes, matcher, weight_dict, losses, invalid_cls_logits, args.hidden_dim, focal_alpha=args.focal_alpha)
    criterion.to(device)
    postprocessors = {'bbox': PostProcess(invalid_cls_logits, temperature=args.obj_temp/args.hidden_dim)}
    exemplar_selection = ExemplarSelection(args, num_classes, matcher, invalid_cls_logits, temperature=args.obj_temp/args.hidden_dim)
    if args.masks:
        postprocessors['segm'] = PostProcessSegm()
        if args.dataset_file == "coco_panoptic":
            is_thing_map = {i: i <= 90 for i in range(201)}
            postprocessors["panoptic"] = PostProcessPanoptic(is_thing_map, threshold=0.85)

    return model, criterion, postprocessors, exemplar_selection
