#!/usr/bin/env bash
# ------------------------------------------------------------------------
# OW-DETR: Open-world Detection Transformer
# Akshita Gupta^, Sanath Narayan^, K J Joseph, Salman Khan, Fahad Shahbaz Khan, Mubarak Shah
# https://arxiv.org/pdf/2112.01513.pdf
# ------------------------------------------------------------------------
# Modified from Deformable DETR (https://github.com/fundamentalvision/Deformable-DETR)
# Copyright (c) 2020 SenseTime. All Rights Reserved.
# ------------------------------------------------------------------------

export CC=gcc-6  # �滻Ϊ����Ҫ��� gcc �汾·��
export CXX=g++-6  # �滻Ϊ����Ҫ��� g++ �汾·��
python setup.py build install
