from pycocotools.coco import COCO
import numpy as np
import collections 

T1_CLASS_NAMES = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27', '28', '29', '30', '31', '32', '33', '34', '35', '36', '37', '38', '39', '40', '41', '42', '43', '44', '45', '46', '47', '48', '49', '50', '51', '52', '53', '54', '55', '56', '57', '58', '59', '60', '61', '62', '63', '64', '65', '66', '67', '68', '69', '70', '71', '72', '73', '74', '75', '76', '77', '78', '79', '80', '81', '82', '83', '84', '85', '86', '87', '88', '89', '90', '91', '92', '93', '94', '95', '96', '97', '98', '99', '100', '101', '102', '103', '104', '105', '106', '107', '108', '109', '110', '111', '112', '113', '114', '115', '116', '117', '118', '119', '120', '121', '122', '123', '124', '125', '126', '127', '128', '129', '130', '131', '132', '133', '134', '135', '136', '137', '138', '139', '140', '141', '142', '143', '144', '145', '146', '147', '148', '149', '150', '151', '152', '153', '154', '155', '156', '157', '158', '159', '160', '161', '162', '163', '164', '165', '166', '167', '168', '169', '170', '171', '172', '173', '174', '175', '176', '177', '178', '179', '180', '181', '182', '183', '184', '185', '186', '187', '188', '189', '190', '191', '192', '193', '194', '195', '196', '197', '198', '199', '200', '201', '202', '203', '204', '205', '206', '207', '208', '209', '210', '211', '212', '213', '214', '215', '216', '217', '218', '219', '220', '221', '222', '223', '224', '225', '226', '227', '228', '229', '230', '231', '232', '233', '234', '235', '236', '237', '238', '239', '240', '241', '242', '243', '244', '245', '246', '247', '248', '249', '250', '251', '252', '253', '254', '255', '256', '257', '258', '259', '260', '261', '262', '263', '264', '265', '266', '267', '268', '269', '270', '271', '272', '273', '274', '275', '276', '277', '278', '279', '280', '281', '282', '283', '284', '285', '286', '287', '288', '289', '290', '291', '292', '293', '294', '295', '296', '297', '298', '299', '300', '301', '302', '303', '304', '305', '306', '307', '308', '309', '310', '311', '312', '313', '314', '315', '316', '317', '318', '319', '320', '321', '322', '323', '324', '325', '326', '327', '328', '329', '330', '331', '332', '333', '334', '335', '336', '337', '338', '339', '340', '341', '342', '343', '344', '345', '346', '347', '348', '349', '350', '351', '352', '353', '354', '355', '356', '357', '358', '359', '360', '361', '362', '363', '364', '365', '366', '367', '368', '369', '370', '371', '372', '373', '374', '375']


import os
import random

# Train
coco_annotation_file = '/icislab/volume1/yuanzhongming/OW-DETR-main/data/VOC2007/1500/An/instances_train.json'
dest_file = '/icislab/volume1/yuanzhongming/OW-DETR-main/data/VOC2007/1500/ImageSets/new_meta_t1_train.txt'

coco_instance = COCO(coco_annotation_file)

image_cls_map = {}  
for image_id in coco_instance.imgToAnns:
    image_details = coco_instance.imgs[image_id]
    classes = [coco_instance.cats[annotation['category_id']]['name'] for annotation in
               coco_instance.imgToAnns[image_id]]
    if set(classes).issubset(T1_CLASS_NAMES):
        image_cls_map[image_details['file_name'].split('.')[0]] = classes


sorted_image_ids = sorted(image_cls_map, key=lambda x: (image_cls_map[x], x))


count_dict = collections.Counter([cls for classes in image_cls_map.values() for cls in classes])
sorted_count_dict = {k: v for k, v in sorted(count_dict.items(), key=lambda item: item[0])}
for cls_name, count in sorted_count_dict.items():
    print(cls_name, count)


with open(dest_file, 'w') as file:
    image_pairs = [(sorted_image_ids[i], sorted_image_ids[i+1]) for i in range(0, len(sorted_image_ids)-1, 2)]
    if len(sorted_image_ids) % 2 == 1:
        image_pairs.append((sorted_image_ids[-1], sorted_image_ids[-2]))
    random.shuffle(image_pairs)

    for image_pair in image_pairs:
        file.write(image_pair[0] + os.linesep)
        file.write(image_pair[1] + os.linesep)

print('666')
"""
# Test
coco_annotation_file = '/yuanzhongming/PROB-main/data/1500_coco/annotations/instances_test.json'
dest_file = '/yuanzhongming/PROB-main/data/1500/ImageSets/Main/t1_test.txt'

coco_instance = COCO(coco_annotation_file)

image_ids = []
cls = []
for index, image_id in enumerate(coco_instance.imgToAnns):
    image_details = coco_instance.imgs[image_id]
    classes = [coco_instance.cats[annotation['category_id']]['name'] for annotation in coco_instance.imgToAnns[image_id]]
    if not set(classes).isdisjoint(T1_CLASS_NAMES):
        image_ids.append(image_details['file_name'].split('.')[0])
        cls.extend(classes)

(unique, counts) = np.unique(cls, return_counts=True)
print({x:y for x,y in zip(unique, counts)})

c = 0
for x,y in zip(unique, counts):
    if x in T1_CLASS_NAMES:
        c += y
print(c)
print(len(image_ids))

with open(dest_file, 'w') as file:
    for image_id in image_ids:
        file.write(str(image_id)+'\n')
print('Created test file')

# Val
coco_annotation_file = '/yuanzhongming/PROB-main/data/1500_coco/annotations/instances_val.json'
dest_file = '/yuanzhongming/PROB-main/data/1500/ImageSets/Main/val.txt'

coco_instance = COCO(coco_annotation_file)

image_ids = []
cls = []
for index, image_id in enumerate(coco_instance.imgToAnns):
    image_details = coco_instance.imgs[image_id]
    classes = [coco_instance.cats[annotation['category_id']]['name'] for annotation in coco_instance.imgToAnns[image_id]]
    if not set(classes).isdisjoint(T1_CLASS_NAMES):
        image_ids.append(image_details['file_name'].split('.')[0])
        cls.extend(classes)

(unique, counts) = np.unique(cls, return_counts=True)
print({x:y for x,y in zip(unique, counts)})

c = 0
for x,y in zip(unique, counts):
    if x in T1_CLASS_NAMES:
        c += y
print(c)
print(len(image_ids))

with open(dest_file, 'w') as file:
    for image_id in image_ids:
        file.write(str(image_id)+'\n')
print('Created test file')"""