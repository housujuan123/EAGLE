import os
import shutil
import sys
import json
import glob
import xml.etree.ElementTree as ET

START_BOUNDING_BOX_ID = 1 
# PRE_DEFINE_CATEGORIES = None
# If necessary, pre-define category and its id

PRE_DEFINE_CATEGORIES = {'corona_text':1,'verizon':2,'starbucks':3,'esso_text':4,'bosch_text':5,'walmart_text':6,'opel':7,'gillette':8,'wellsfargo':9,'millerhighlife':10,'axa':11,'netflix':12,'redbull':13,'bridgestone':14,'bellodigital':15,'umbro':16,'chevrolet':17,'amcrest':18,'fly_emirates':19,'hh':20,'sprite':21,'nintendo':22,'paulaner':23,'aldi':24,'bosch':25,'aspirin':26,'mccafe':27,'fedex':28,'hyundai_text':29,'bik':30,'santander':31,'heineken':32,'oracle':33,'subaru':34,'3m':35,'hyundai':36,'shell_text':37,'lexus_text':38,'quick':39,'jello':40,'ec':41,'head':42,'philips':43,'hp':44,'maxxis':45,'adidas1':46,'unicef':47,'microsoft':48,'asus':49,'lacoste':50,'t-mobile':51,'armani':52,'obey':53,'marlboro_fig':54,'homedepot':55,'allianz_text':56,'windows':57,'rolex_text':58,'chanel_text':59,'reebok_text':60,'jagermeister':61,'jackinthebox':62,'vaio':63,'renault':64,'mercedesbenz':65,'kia':66,'boeing':67,'optus_yes':68,'hisense':69,'optus':70,'singha':71,'uniqlo':72,'benrus':73,'barclays':74,'athalon':75,'amazon':76,'fritos':77,'subway':78,'firefox':79,'bellodigital_text':80,'disney':81,'infiniti':82,'verizon_text':83,'lamborghini':84,'uniqlo1':85,'reeses':86,'adidas_text':87,'marlboro_text':88,'pampers':89,'nasa':90,'jacobscreek':91,'planters':92,'ferrari':93,'underarmour':94,'at_and_t':95,'bbva':96,'lacoste_text':97,'sega':98,'chanel':99,'basf':100,'samsung':101,'ford':102,'yahoo':103,'heraldsun':104,'canon':105,'tnt':106,'scion_text':107,'comedycentral':108,'teslamotors':109,'bmw':110,'bionade':111,'pepsi_text1':112,'adidas':113,'londonunderground':114,'lotto':115,'blizzardentertainment':116,'hsbc':117,'cvs':118,'wellsfargo_text':119,'chevrolet_text':120,'burgerking_text':121,'rolex':122,'toyota_text':123,'costco':124,'airness':125,'suzuki':126,'facebook':127,'total':128,'bankofamerica_text':129,'texaco':130,'hm':131,'caterpillar':132,'fritolay':133,'cpa_australia':134,'gap':135,'honda_text':136,'rittersport':137,'us_president':138,'cartier':139,'thomsonreuters':140,'tacobell':141,'americanexpress_text':142,'amcrest_text':143,'wordpress':144,'budweiser_text':145,'cheetos':146,'boeing_text':147,'danone':148,'corona':149,'republican':150,'generalelectric':151,'carlsberg':152,'citroen_text':153,'tigerwash':154,'bayer':155,'audi_text':156,'puma_text':157,'guinness':158,'nissan':159,'select':160,'johnnywalker':161,'shell':162,'aquapac_text':163,'carters':164,'soundcloud':165,'velveeta':166,'tommyhilfiger':167,'youtube':168,'dhl':169,'marlboro':170,'lexus':171,'mk':172,'mitsubishi':173,'xbox':174,'northface':175,'internetexplorer':176,'cvspharmacy':177,'nissan_text':178,'rbc':179,'heineken_text':180,'bankofamerica':181,'pizzahut':182,'loreal':183,'mcdonalds_text':184,'aluratek':185,'yonex':186,'aluratek_text':187,'batman':188,'blackmores':189,'luxottica':190,'kodak':191,'supreme':192,'hsbc_text':193,'apc':194,'aral':195,'spiderman':196,'wii':197,'spar_text':198,'calvinklein':199,'dunkindonuts':200,'converse':201,'erdinger':202,'dexia':203,'drpepper':204,'venus':205,'maxwellhouse':206,'burgerking':207,'mini':208,'google':209,'nescafe':210,'intel':211,'poloralphlauren':212,'jcrew':213,'bbc':214,'colgate':215,'fosters':216,'gucci':217,'bridgestone_text':218,'ibm':219,'mcdonalds':220,'apple':221,'nvidia':222,'ikea':223,'sap':224,'bacardi':225,'barbie':226,'carglass':227,'android':228,'anz':229,'infiniti_text':230,'pizzahut_hut':231,'timberland':232,'philadelphia':233,'superman':234,'target':235,'porsche_text':236,'huawei_text':237,'nb':238,'prada':239,'goodyear':240,'motorola':241,'huawei':242,'skechers':243,'hanes':244,'zara':245,'allett':246,'honda':247,'reebok':248,'michelin':249,'bem':250,'alfaromeo':251,'bulgari':252,'bottegaveneta':253,'stellaartois':254,'lv':255,'yonex_text':256,'vodafone':257,'kitkat':258,'accenture':259,'toyota':260,'evernote':261,'anz_text':262,'pepsi_text':263,'walmart':264,'mercedesbenz_text':265,'armitron':266,'budweiser':267,'miraclewhip':268,'chickfila':269,'shell_text1':270,'pepsi':271,'spar':272,'abus':273,'cocacola':274,'audi':275,'olympics':276,'medibank':277,'recycling':278,'nike':279,'airhawk':280,'costa':281,'nike_text':282,'chiquita':283,'apecase':284,'homedepot_text':285,'tostitos':286,'hermes':287,'tissot':288,'mastercard':289,'williamhill':290,'volvo':291,'redbull_text':292,'allianz':293,'sony':294,'standard_liege':295,'schwinn':296,'firelli':297,'visa':298,'lego':299,'puma':300,'milka':301,'nivea':302,'maserati':303,'reebok1':304,'doritos':305,'espn':306,'panasonic':307,'bfgoodrich':308,'warnerbros':309,'volkswagen_text':310,'chevron':311,'citroen':312,'ruffles':313,'jurlique':314,'hersheys':315,'cisco':316,'citi':317,'americanexpress':318,'coke':319,'ebay':320,'bershka':321,'becks':322,'kfc':323,'siemens':324,'kelloggs':325,'sunchips':326,'unitednations':327,'kraft':328,'base':329,'mtv':330,'aldi_text':331,'twitter':332,'porsche':333,'coach':334,'volkswagen':335,'gildan':336,'bellataylor':337,'head_text':338,'ups':339,'mobil':340,'chimay':341,'playstation':342,'lays':343,'soundrop':344,'esso':345,'santander_text':346,'yamaha':347,'tsingtao':348,'target_text':349,'lg':350,'nbc':351,'levis':352}
def get(root, name):
    vars = root.findall(name)
    return vars


def get_and_check(root, name, length):
    vars = root.findall(name)
    if len(vars) == 0:
        raise ValueError("Can not find %s in %s." % (name, root.tag))
    if length > 0 and len(vars) != length:
        raise ValueError(
            "The size of %s is supposed to be %d, but is %d."
            % (name, length, len(vars))
        )
    if length == 1:
        vars = vars[0]
    return vars


def get_filename_as_int(filename):
    try:
        filename = filename.replace("\\", "/")
        filename = os.path.splitext(os.path.basename(filename))[0]
        return int(filename)
    except:
        raise ValueError(
            "Filename %s is supposed to be an integer." % (filename))


def get_categories(xml_files):
    """Generate category name to id mapping from a list of xml files.

    Arguments:
        xml_files {list} -- A list of xml file paths.

    Returns:
        dict -- category name to id mapping.
    """
    classes_names = []
    for xml_file in xml_files:
        tree = ET.parse(xml_file)
        root = tree.getroot()
        for member in root.findall("object"):
            classes_names.append(member[0].text)
    classes_names = list(set(classes_names))
    classes_names.sort()
    return {name: i for i, name in enumerate(classes_names)}


def convert(xml_files, json_file):
    json_dict = {"images": [], "type": "instances",
                 "annotations": [], "categories": []}
    if PRE_DEFINE_CATEGORIES is not None:
        categories = PRE_DEFINE_CATEGORIES
    else:
        categories = get_categories(xml_files)
    bnd_id = START_BOUNDING_BOX_ID
    for xml_file in xml_files:
        tree = ET.parse(xml_file)
        root = tree.getroot()
        path = get(root, "path")
        if len(path) == 1:
            filename = os.path.basename(path[0].text)
        elif len(path) == 0:
            filename = get_and_check(root, "filename", 1).text
        else:
            raise ValueError("%d paths found in %s" % (len(path), xml_file))
        # The filename must be a number
        image_id = get_filename_as_int(filename)
        size = get_and_check(root, "size", 1)
        width = int(get_and_check(size, "width", 1).text)
        height = int(get_and_check(size, "height", 1).text)
        image = {
            "file_name": filename,
            "height": height,
            "width": width,
            "id": image_id,
        }
        json_dict["images"].append(image)
        # Currently we do not support segmentation.
        #  segmented = get_and_check(root, 'segmented', 1).text
        #  assert segmented == '0'
        for obj in get(root, "object"):
            category = get_and_check(obj, "name", 1).text
            if category not in categories:
                new_id = len(categories)
                categories[category] = new_id
            category_id = categories[category]
            bndbox = get_and_check(obj, "bndbox", 1)
            xmin = int(get_and_check(bndbox, "xmin", 1).text) - 1
            ymin = int(get_and_check(bndbox, "ymin", 1).text) - 1
            xmax = int(get_and_check(bndbox, "xmax", 1).text)
            ymax = int(get_and_check(bndbox, "ymax", 1).text)
            assert xmax > xmin
            assert ymax > ymin
            o_width = abs(xmax - xmin)
            o_height = abs(ymax - ymin)
            ann = {
                "area": o_width * o_height,
                "iscrowd": 0,
                "image_id": image_id,
                "bbox": [xmin, ymin, o_width, o_height],
                "category_id": category_id,
                "id": bnd_id,
                "ignore": 0,
                "segmentation": [],
            }
            json_dict["annotations"].append(ann)
            bnd_id = bnd_id + 1

    for cate, cid in categories.items():
        cat = {"supercategory": "none", "id": cid, "name": cate}
        json_dict["categories"].append(cat)

    os.makedirs(os.path.dirname(json_file), exist_ok=True)
    json_fp = open(json_file, "w")
    json_str = json.dumps(json_dict)
    json_fp.write(json_str)
    json_fp.close()


if __name__ == "__main__":
    #  只需修改以下两个路径
    #  VOC数据集根目录
    voc_path = "/icislab/volume1/yuanzhongming/DETR/datasets/openlogo/VOC2007"

    #  保存coco格式数据集根目录
    save_coco_path = "/icislab/volume1/yuanzhongming/DETR/datasets/openlogo1/VOC2COCO"

    #  VOC只分了训练集和验证集即train.txt和val.txt
    data_type_list = ["trainval", "test"]
    for data_type in data_type_list:
        os.makedirs(os.path.join(save_coco_path, data_type + "2017"))
        os.makedirs(os.path.join(save_coco_path, data_type + "_xml"))
        with open(os.path.join(voc_path, "ImageSets/Main", data_type + ".txt"), "r") as f:
            txt_ls = f.readlines()
        txt_ls = [i.strip() for i in txt_ls]
        for i in os.listdir(os.path.join(voc_path, "JPEGImages")):
            if os.path.splitext(i)[0] in txt_ls:
                shutil.copy(os.path.join(voc_path, "JPEGImages", i),
                            os.path.join(save_coco_path, data_type + "2017", i))
                shutil.copy(os.path.join(voc_path, "Annotations", i[:-4] + ".xml"), os.path.join(
                    save_coco_path, data_type + "_xml", i[:-4] + ".xml"))
        xml_path = os.path.join(save_coco_path, data_type + "_xml")
        xml_files = glob.glob(os.path.join(xml_path, "*.xml"))
        convert(xml_files, os.path.join(save_coco_path,
                                        "annotations", "instances_" + data_type + "2017.json"))
        shutil.rmtree(xml_path)


